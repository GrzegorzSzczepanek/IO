package hotel.model;

/**
 * Interfejs dodatku do rezerwacji.
 */
public interface IDodatek {
    double obliczDodatkowyKoszt();
    String getOpis();
}
