package pl.pwr.hotel.factory;

import pl.pwr.hotel.entity.Gosc;

/**
 * Interfejs fabryki gości.
 * Wzorzec Fabryka - definiuje kontrakt dla tworzenia obiektów Gosc.
 */
public interface IGoscFactory {
    
    /**
     * Tworzy nowego gościa z podanymi danymi.
     * @param imie imię gościa
     * @param nazwisko nazwisko gościa
     * @param email adres email gościa
     * @return nowo utworzony obiekt Gosc
     */
    Gosc utworzGoscia(String imie, String nazwisko, String email);
}
