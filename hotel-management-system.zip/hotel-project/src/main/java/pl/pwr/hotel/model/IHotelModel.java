package pl.pwr.hotel.model;

import pl.pwr.hotel.entity.Gosc;
import pl.pwr.hotel.entity.Pokoj;
import pl.pwr.hotel.entity.Rezerwacja;
import java.time.LocalDate;
import java.util.List;

/**
 * Interfejs modelu hotelowego.
 * Definiuje główne operacje biznesowe systemu.
 */
public interface IHotelModel {
    
    // ========== Operacje na rezerwacjach ==========
    
    /**
     * Tworzy nową rezerwację.
     * @param goscId identyfikator gościa
     * @param pokojNumer numer pokoju
     * @param dataOd data rozpoczęcia
     * @param dataDo data zakończenia
     * @return utworzona rezerwacja
     */
    Rezerwacja utworzRezerwacje(int goscId, int pokojNumer, LocalDate dataOd, LocalDate dataDo);
    
    /**
     * Anuluje rezerwację.
     * @param rezerwacjaId identyfikator rezerwacji
     * @return true jeśli anulowano pomyślnie
     */
    boolean anulujRezerwacje(int rezerwacjaId);
    
    /**
     * Modyfikuje istniejącą rezerwację.
     * @param rezerwacjaId identyfikator rezerwacji
     * @param nowaDataOd nowa data rozpoczęcia
     * @param nowaDataDo nowa data zakończenia
     * @return zmodyfikowana rezerwacja
     */
    Rezerwacja modyfikujRezerwacje(int rezerwacjaId, LocalDate nowaDataOd, LocalDate nowaDataDo);
    
    /**
     * Znajduje rezerwacje spełniające kryteria.
     * @param dataOd data początkowa (może być null)
     * @param dataDo data końcowa (może być null)
     * @return lista rezerwacji
     */
    List<Rezerwacja> znajdzRezerwacje(LocalDate dataOd, LocalDate dataDo);
    
    // ========== Operacje na pokojach ==========
    
    /**
     * Znajduje dostępne pokoje w danym okresie.
     * @param dataOd data początkowa
     * @param dataDo data końcowa
     * @return lista dostępnych pokoi
     */
    List<Pokoj> znajdzDostepnePokoje(LocalDate dataOd, LocalDate dataDo);
    
    /**
     * Aktualizuje status pokoju.
     * @param numerPokoju numer pokoju
     * @param nowyStatus nowy status
     * @return true jeśli zaktualizowano pomyślnie
     */
    boolean aktualizujStatusPokoju(int numerPokoju, Pokoj.StatusPokoju nowyStatus);
    
    // ========== Operacje na gościach ==========
    
    /**
     * Tworzy profil nowego gościa.
     * @param imie imię gościa
     * @param nazwisko nazwisko gościa
     * @param email adres email gościa
     * @return utworzony gość
     */
    Gosc utworzProfilGoscia(String imie, String nazwisko, String email);
    
    /**
     * Znajduje profil gościa po identyfikatorze.
     * @param goscId identyfikator gościa
     * @return gość lub null jeśli nie znaleziono
     */
    Gosc znajdzProfilGoscia(int goscId);
    
    // ========== Operacje finansowe ==========
    
    /**
     * Pobiera opłatę za rezerwację.
     * @param rezerwacjaId identyfikator rezerwacji
     * @return kwota do zapłaty
     */
    double pobierzOplate(int rezerwacjaId);
    
    /**
     * Potwierdza płatność za rezerwację.
     * @param rezerwacjaId identyfikator rezerwacji
     * @return true jeśli płatność potwierdzona
     */
    boolean potwierdzPlatnosc(int rezerwacjaId);
}
