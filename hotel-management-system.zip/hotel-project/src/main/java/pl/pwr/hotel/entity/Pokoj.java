package pl.pwr.hotel.entity;

/**
 * Klasa encji reprezentująca pokój hotelowy.
 * Warstwa encji - Model w MVC.
 */
public class Pokoj {
    
    private int numer;
    private String typ;
    private double cena;
    private StatusPokoju status;
    
    /**
     * Enum reprezentujący status pokoju.
     */
    public enum StatusPokoju {
        DOSTEPNY,
        ZAJETY,
        W_SPRZATANIU,
        NIEDOSTEPNY
    }
    
    /**
     * Konstruktor domyślny.
     */
    public Pokoj() {
        this.status = StatusPokoju.DOSTEPNY;
    }
    
    /**
     * Konstruktor z parametrami.
     * @param numer numer pokoju
     * @param typ typ pokoju (np. "jednoosobowy", "dwuosobowy", "apartament")
     * @param cena cena bazowa za dobę
     */
    public Pokoj(int numer, String typ, double cena) {
        this.numer = numer;
        this.typ = typ;
        this.cena = cena;
        this.status = StatusPokoju.DOSTEPNY;
    }
    
    /**
     * Pobiera numer pokoju.
     * @return numer pokoju
     */
    public int getNumer() {
        return numer;
    }
    
    /**
     * Ustawia numer pokoju.
     * @param numer numer pokoju
     */
    public void setNumer(int numer) {
        this.numer = numer;
    }
    
    /**
     * Pobiera typ pokoju.
     * @return typ pokoju
     */
    public String getTyp() {
        return typ;
    }
    
    /**
     * Ustawia typ pokoju.
     * @param typ typ pokoju
     */
    public void setTyp(String typ) {
        this.typ = typ;
    }
    
    /**
     * Pobiera cenę bazową pokoju za dobę.
     * @return cena bazowa
     */
    public double getCenaBazowa() {
        return cena;
    }
    
    /**
     * Ustawia cenę bazową pokoju.
     * @param cena cena bazowa
     */
    public void setCena(double cena) {
        this.cena = cena;
    }
    
    /**
     * Pobiera aktualny status pokoju.
     * @return status pokoju
     */
    public StatusPokoju getStatus() {
        return status;
    }
    
    /**
     * Ustawia status pokoju.
     * @param status nowy status pokoju
     */
    public void setStatus(StatusPokoju status) {
        this.status = status;
    }
    
    /**
     * Sprawdza czy pokój jest dostępny.
     * @return true jeśli pokój jest dostępny
     */
    public boolean czyDostepny() {
        return status == StatusPokoju.DOSTEPNY;
    }
    
    @Override
    public String toString() {
        return "Pokoj{" +
                "numer=" + numer +
                ", typ='" + typ + '\'' +
                ", cena=" + cena +
                ", status=" + status +
                '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pokoj pokoj = (Pokoj) o;
        return numer == pokoj.numer;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(numer);
    }
}
