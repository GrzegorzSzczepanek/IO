package pl.pwr.hotel.controller;

import pl.pwr.hotel.entity.Pokoj;
import pl.pwr.hotel.model.IHotelModel;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementacja kontrolera pokoi.
 * Obsługuje operacje związane z zarządzaniem pokojami.
 */
public class PokojeKontroler implements IPokojeKontroler {
    
    private final IHotelModel model;
    private final Map<Integer, List<String>> inwentarzPokoi;
    private final Map<Integer, List<String>> usterkiPokoi;
    
    /**
     * Konstruktor z wstrzykiwaniem modelu.
     * @param model model hotelowy
     */
    public PokojeKontroler(IHotelModel model) {
        this.model = model;
        this.inwentarzPokoi = new HashMap<>();
        this.usterkiPokoi = new HashMap<>();
    }
    
    @Override
    public List<Pokoj> wyszukajDostepnePokoje(LocalDate dataOd, LocalDate dataDo) {
        if (dataOd == null || dataDo == null) {
            throw new IllegalArgumentException("Daty nie mogą być null");
        }
        if (!dataOd.isBefore(dataDo)) {
            throw new IllegalArgumentException("Data rozpoczęcia musi być przed datą zakończenia");
        }
        return model.znajdzDostepnePokoje(dataOd, dataDo);
    }
    
    @Override
    public boolean przypiszPokoj(int pokojNumer, int goscId) {
        // Sprawdzenie czy pokój istnieje i jest dostępny
        List<Pokoj> dostepne = model.znajdzDostepnePokoje(LocalDate.now(), LocalDate.now().plusDays(1));
        boolean pokojDostepny = dostepne.stream()
                .anyMatch(p -> p.getNumer() == pokojNumer);
        
        if (!pokojDostepny) {
            return false;
        }
        
        // Zmiana statusu pokoju na zajęty
        return model.aktualizujStatusPokoju(pokojNumer, Pokoj.StatusPokoju.ZAJETY);
    }
    
    @Override
    public boolean aktualizujStatusPokoju(int pokojNumer, Pokoj.StatusPokoju nowyStatus) {
        return model.aktualizujStatusPokoju(pokojNumer, nowyStatus);
    }
    
    @Override
    public boolean sprzatanie(int pokojNumer) {
        // Oznacz pokój jako dostępny po sprzątaniu
        return model.aktualizujStatusPokoju(pokojNumer, Pokoj.StatusPokoju.DOSTEPNY);
    }
    
    @Override
    public boolean zglosUsterke(int pokojNumer, String opisUsterki) {
        if (opisUsterki == null || opisUsterki.trim().isEmpty()) {
            throw new IllegalArgumentException("Opis usterki nie może być pusty");
        }
        
        // Zapisz usterkę
        usterkiPokoi.computeIfAbsent(pokojNumer, k -> new ArrayList<>()).add(opisUsterki);
        
        // Zmień status pokoju na niedostępny
        return model.aktualizujStatusPokoju(pokojNumer, Pokoj.StatusPokoju.NIEDOSTEPNY);
    }
    
    @Override
    public boolean zarzadzajInwentarzem(int pokojNumer, List<String> elementy) {
        if (elementy == null) {
            throw new IllegalArgumentException("Lista elementów nie może być null");
        }
        
        inwentarzPokoi.put(pokojNumer, new ArrayList<>(elementy));
        return true;
    }
    
    /**
     * Pobiera inwentarz pokoju.
     * @param pokojNumer numer pokoju
     * @return lista elementów inwentarza
     */
    public List<String> pobierzInwentarz(int pokojNumer) {
        return new ArrayList<>(inwentarzPokoi.getOrDefault(pokojNumer, new ArrayList<>()));
    }
    
    /**
     * Pobiera zgłoszone usterki dla pokoju.
     * @param pokojNumer numer pokoju
     * @return lista usterek
     */
    public List<String> pobierzUsterki(int pokojNumer) {
        return new ArrayList<>(usterkiPokoi.getOrDefault(pokojNumer, new ArrayList<>()));
    }
    
    /**
     * Usuwa usterkę z listy (po naprawie).
     * @param pokojNumer numer pokoju
     * @param opisUsterki opis usterki do usunięcia
     * @return true jeśli usunięto
     */
    public boolean usunUsterke(int pokojNumer, String opisUsterki) {
        List<String> usterki = usterkiPokoi.get(pokojNumer);
        if (usterki != null) {
            return usterki.remove(opisUsterki);
        }
        return false;
    }
}
