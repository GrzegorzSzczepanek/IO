package pl.pwr.hotel.entity;

/**
 * Klasa reprezentująca dodatek śniadaniowy do rezerwacji.
 * Implementuje interfejs IDodatek.
 */
public class Sniadanie implements IDodatek {
    
    private double cena;
    private String typSniadania;
    
    /**
     * Konstruktor domyślny - standardowe śniadanie.
     */
    public Sniadanie() {
        this.cena = 50.0;
        this.typSniadania = "standardowe";
    }
    
    /**
     * Konstruktor z ceną.
     * @param cena cena śniadania
     */
    public Sniadanie(double cena) {
        this.cena = cena;
        this.typSniadania = "standardowe";
    }
    
    /**
     * Konstruktor pełny.
     * @param cena cena śniadania
     * @param typSniadania typ śniadania (np. "standardowe", "premium")
     */
    public Sniadanie(double cena, String typSniadania) {
        this.cena = cena;
        this.typSniadania = typSniadania;
    }
    
    @Override
    public double obliczDodatkowyKoszt() {
        return cena;
    }
    
    @Override
    public String getOpis() {
        return "Śniadanie " + typSniadania + " - " + cena + " PLN/dzień";
    }
    
    /**
     * Pobiera cenę śniadania.
     * @return cena śniadania
     */
    public double getCena() {
        return cena;
    }
    
    /**
     * Ustawia cenę śniadania.
     * @param cena nowa cena
     */
    public void setCena(double cena) {
        this.cena = cena;
    }
    
    /**
     * Pobiera typ śniadania.
     * @return typ śniadania
     */
    public String getTypSniadania() {
        return typSniadania;
    }
    
    /**
     * Ustawia typ śniadania.
     * @param typSniadania typ śniadania
     */
    public void setTypSniadania(String typSniadania) {
        this.typSniadania = typSniadania;
    }
    
    @Override
    public String toString() {
        return "Sniadanie{" +
                "cena=" + cena +
                ", typSniadania='" + typSniadania + '\'' +
                '}';
    }
}
