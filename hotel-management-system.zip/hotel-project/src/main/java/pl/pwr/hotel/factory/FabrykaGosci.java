package pl.pwr.hotel.factory;

import pl.pwr.hotel.entity.Gosc;

/**
 * Implementacja fabryki gości.
 * Wzorzec Fabryka - tworzy obiekty Gosc.
 */
public class FabrykaGosci implements IGoscFactory {
    
    private int nextId;
    
    /**
     * Konstruktor domyślny.
     */
    public FabrykaGosci() {
        this.nextId = 1;
    }
    
    @Override
    public Gosc utworzGoscia(String imie, String nazwisko, String email) {
        // Walidacja danych wejściowych
        if (imie == null || imie.trim().isEmpty()) {
            throw new IllegalArgumentException("Imię nie może być puste");
        }
        if (nazwisko == null || nazwisko.trim().isEmpty()) {
            throw new IllegalArgumentException("Nazwisko nie może być puste");
        }
        if (email == null || !email.contains("@")) {
            throw new IllegalArgumentException("Nieprawidłowy adres email");
        }
        
        Gosc gosc = new Gosc(nextId++, imie.trim(), nazwisko.trim(), email.trim().toLowerCase());
        return gosc;
    }
    
    /**
     * Tworzy gościa z pełnym identyfikatorem (dla importu danych).
     * @param id identyfikator gościa
     * @param imie imię gościa
     * @param nazwisko nazwisko gościa
     * @param email adres email gościa
     * @return nowo utworzony obiekt Gosc
     */
    public Gosc utworzGosciaZId(int id, String imie, String nazwisko, String email) {
        if (id <= 0) {
            throw new IllegalArgumentException("Identyfikator musi być dodatni");
        }
        if (imie == null || imie.trim().isEmpty()) {
            throw new IllegalArgumentException("Imię nie może być puste");
        }
        if (nazwisko == null || nazwisko.trim().isEmpty()) {
            throw new IllegalArgumentException("Nazwisko nie może być puste");
        }
        if (email == null || !email.contains("@")) {
            throw new IllegalArgumentException("Nieprawidłowy adres email");
        }
        
        // Aktualizuj nextId jeśli przekazany id jest większy
        if (id >= nextId) {
            nextId = id + 1;
        }
        
        return new Gosc(id, imie.trim(), nazwisko.trim(), email.trim().toLowerCase());
    }
    
    /**
     * Resetuje licznik identyfikatorów.
     */
    public void resetujLicznik() {
        this.nextId = 1;
    }
    
    /**
     * Pobiera następny dostępny identyfikator.
     * @return następny identyfikator
     */
    public int getNastepnyId() {
        return nextId;
    }
}
