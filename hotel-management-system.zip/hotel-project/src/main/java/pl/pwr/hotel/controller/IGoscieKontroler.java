package pl.pwr.hotel.controller;

import pl.pwr.hotel.entity.Gosc;

/**
 * Interfejs kontrolera gości.
 * Definiuje operacje związane z zarządzaniem profilami gości.
 */
public interface IGoscieKontroler {
    
    /**
     * Przegląda profil gościa.
     * @param goscId identyfikator gościa
     * @return profil gościa
     */
    Gosc przegladProfiluGoscia(int goscId);
    
    /**
     * Edytuje profil gościa.
     * @param goscId identyfikator gościa
     * @param noweImie nowe imię (null jeśli bez zmian)
     * @param noweNazwisko nowe nazwisko (null jeśli bez zmian)
     * @param nowyEmail nowy email (null jeśli bez zmian)
     * @return zaktualizowany profil gościa
     */
    Gosc edytujProfilGoscia(int goscId, String noweImie, String noweNazwisko, String nowyEmail);
    
    /**
     * Tworzy profil nowego gościa.
     * @param imie imię gościa
     * @param nazwisko nazwisko gościa
     * @param email adres email gościa
     * @return utworzony profil gościa
     */
    Gosc utworzProfilGoscia(String imie, String nazwisko, String email);
}
