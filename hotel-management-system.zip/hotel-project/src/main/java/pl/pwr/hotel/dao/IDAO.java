package pl.pwr.hotel.dao;

import java.util.List;

/**
 * Generyczny interfejs DAO (Data Access Object).
 * Definiuje podstawowe operacje CRUD.
 * @param <T> typ encji
 */
public interface IDAO<T> {
    
    /**
     * Pobiera encję po identyfikatorze.
     * @param id identyfikator encji
     * @return encja lub null jeśli nie znaleziono
     */
    T pobierz(int id);
    
    /**
     * Zapisuje nową encję.
     * @param obiekt encja do zapisania
     */
    void zapisz(T obiekt);
    
    /**
     * Usuwa encję po identyfikatorze.
     * @param id identyfikator encji do usunięcia
     * @return true jeśli usunięto pomyślnie
     */
    boolean usun(int id);
    
    /**
     * Pobiera wszystkie encje.
     * @return lista wszystkich encji
     */
    List<T> pobierzWszystkie();
    
    /**
     * Aktualizuje istniejącą encję.
     * @param obiekt encja do aktualizacji
     */
    void aktualizuj(T obiekt);
}
