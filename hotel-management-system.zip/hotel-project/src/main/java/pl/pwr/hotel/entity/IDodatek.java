package pl.pwr.hotel.entity;

/**
 * Interfejs reprezentujący dodatek do rezerwacji.
 * Wzorzec Strategia - definiuje kontrakt dla różnych typów dodatków.
 */
public interface IDodatek {
    
    /**
     * Oblicza koszt dodatku.
     * @return koszt dodatku
     */
    double obliczDodatkowyKoszt();
    
    /**
     * Pobiera opis dodatku.
     * @return opis dodatku
     */
    String getOpis();
}
