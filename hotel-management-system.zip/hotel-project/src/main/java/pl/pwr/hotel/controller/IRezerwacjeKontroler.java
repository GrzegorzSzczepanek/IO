package pl.pwr.hotel.controller;

import pl.pwr.hotel.entity.Pokoj;
import pl.pwr.hotel.entity.Rezerwacja;
import java.time.LocalDate;
import java.util.List;

/**
 * Interfejs kontrolera rezerwacji.
 * Definiuje operacje związane z zarządzaniem rezerwacjami.
 */
public interface IRezerwacjeKontroler {
    
    /**
     * Tworzy nową rezerwację.
     * @param goscId identyfikator gościa
     * @param pokojNumer numer pokoju
     * @param dataOd data rozpoczęcia
     * @param dataDo data zakończenia
     * @return utworzona rezerwacja
     */
    Rezerwacja utworzRezerwacje(int goscId, int pokojNumer, LocalDate dataOd, LocalDate dataDo);
    
    /**
     * Anuluje rezerwację.
     * @param rezerwacjaId identyfikator rezerwacji
     * @return true jeśli anulowano pomyślnie
     */
    boolean anulujRezerwacje(int rezerwacjaId);
    
    /**
     * Modyfikuje rezerwację.
     * @param rezerwacjaId identyfikator rezerwacji
     * @param nowaDataOd nowa data rozpoczęcia
     * @param nowaDataDo nowa data zakończenia
     * @return zmodyfikowana rezerwacja
     */
    Rezerwacja modyfikujRezerwacje(int rezerwacjaId, LocalDate nowaDataOd, LocalDate nowaDataDo);
    
    /**
     * Przegląda zarezerwowane pokoje.
     * @param dataOd data początkowa
     * @param dataDo data końcowa
     * @return lista rezerwacji
     */
    List<Rezerwacja> przegladajZarezerwowanePokoje(LocalDate dataOd, LocalDate dataDo);
    
    /**
     * Pobiera opłatę za anulowanie rezerwacji.
     * @param rezerwacjaId identyfikator rezerwacji
     * @return kwota opłaty za anulowanie
     */
    double pobierzOplateZaAnulowanie(int rezerwacjaId);
}
