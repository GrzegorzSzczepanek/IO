package pl.pwr.hotel.dao;

import pl.pwr.hotel.entity.Pokoj;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementacja DAO dla encji Pokoj.
 * Przechowuje dane w pamięci (symulacja bazy danych).
 */
public class PokojeDAO implements IDAO<Pokoj> {
    
    private final Map<Integer, Pokoj> pokoje;
    
    /**
     * Konstruktor domyślny.
     */
    public PokojeDAO() {
        this.pokoje = new HashMap<>();
    }
    
    @Override
    public Pokoj pobierz(int numerPokoju) {
        return pokoje.get(numerPokoju);
    }
    
    @Override
    public void zapisz(Pokoj pokoj) {
        if (pokoj != null) {
            pokoje.put(pokoj.getNumer(), pokoj);
        }
    }
    
    @Override
    public boolean usun(int numerPokoju) {
        return pokoje.remove(numerPokoju) != null;
    }
    
    @Override
    public List<Pokoj> pobierzWszystkie() {
        return new ArrayList<>(pokoje.values());
    }
    
    @Override
    public void aktualizuj(Pokoj pokoj) {
        if (pokoj != null && pokoje.containsKey(pokoj.getNumer())) {
            pokoje.put(pokoj.getNumer(), pokoj);
        }
    }
    
    /**
     * Pobiera listę dostępnych pokoi.
     * @return lista dostępnych pokoi
     */
    public List<Pokoj> pobierzDostepne() {
        return pokoje.values().stream()
                .filter(Pokoj::czyDostepny)
                .toList();
    }
    
    /**
     * Pobiera pokoje danego typu.
     * @param typ typ pokoju
     * @return lista pokoi danego typu
     */
    public List<Pokoj> pobierzPoTypie(String typ) {
        return pokoje.values().stream()
                .filter(p -> p.getTyp() != null && p.getTyp().equalsIgnoreCase(typ))
                .toList();
    }
    
    /**
     * Pobiera dostępne pokoje danego typu.
     * @param typ typ pokoju
     * @return lista dostępnych pokoi danego typu
     */
    public List<Pokoj> pobierzDostepnePoTypie(String typ) {
        return pokoje.values().stream()
                .filter(p -> p.czyDostepny() && p.getTyp() != null && p.getTyp().equalsIgnoreCase(typ))
                .toList();
    }
    
    /**
     * Pobiera pokoje w danym przedziale cenowym.
     * @param cenaMin minimalna cena
     * @param cenaMax maksymalna cena
     * @return lista pokoi w przedziale cenowym
     */
    public List<Pokoj> pobierzWPrzedzialeCenowym(double cenaMin, double cenaMax) {
        return pokoje.values().stream()
                .filter(p -> p.getCenaBazowa() >= cenaMin && p.getCenaBazowa() <= cenaMax)
                .toList();
    }
    
    /**
     * Sprawdza czy pokój o danym numerze istnieje.
     * @param numer numer pokoju
     * @return true jeśli pokój istnieje
     */
    public boolean czyIstnieje(int numer) {
        return pokoje.containsKey(numer);
    }
    
    /**
     * Zwraca liczbę pokoi w systemie.
     * @return liczba pokoi
     */
    public int liczbaPokoi() {
        return pokoje.size();
    }
    
    /**
     * Czyści wszystkie pokoje.
     */
    public void wyczyscWszystko() {
        pokoje.clear();
    }
}
