package pl.pwr.hotel.entity;

/**
 * Klasa encji reprezentująca gościa hotelowego.
 * Warstwa encji - Model w MVC.
 */
public class Gosc {
    
    private int id;
    private String imie;
    private String nazwisko;
    private String email;
    private Rezerwacja rezerwacja;
    
    /**
     * Konstruktor domyślny.
     */
    public Gosc() {
    }
    
    /**
     * Konstruktor z parametrami.
     * @param id identyfikator gościa
     * @param imie imię gościa
     * @param nazwisko nazwisko gościa
     * @param email adres email gościa
     */
    public Gosc(int id, String imie, String nazwisko, String email) {
        this.id = id;
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.email = email;
    }
    
    /**
     * Pobiera identyfikator gościa.
     * @return identyfikator gościa
     */
    public int getId() {
        return id;
    }
    
    /**
     * Ustawia identyfikator gościa.
     * @param id identyfikator gościa
     */
    public void setId(int id) {
        this.id = id;
    }
    
    /**
     * Pobiera imię gościa.
     * @return imię gościa
     */
    public String getImie() {
        return imie;
    }
    
    /**
     * Ustawia imię gościa.
     * @param imie imię gościa
     */
    public void setImie(String imie) {
        this.imie = imie;
    }
    
    /**
     * Pobiera nazwisko gościa.
     * @return nazwisko gościa
     */
    public String getNazwisko() {
        return nazwisko;
    }
    
    /**
     * Ustawia nazwisko gościa.
     * @param nazwisko nazwisko gościa
     */
    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }
    
    /**
     * Pobiera adres email gościa.
     * @return adres email gościa
     */
    public String getEmail() {
        return email;
    }
    
    /**
     * Ustawia adres email gościa.
     * @param email adres email gościa
     */
    public void setEmail(String email) {
        this.email = email;
    }
    
    /**
     * Pobiera rezerwację przypisaną do gościa.
     * @return rezerwacja gościa
     */
    public Rezerwacja getRezerwacja() {
        return rezerwacja;
    }
    
    /**
     * Ustawia rezerwację dla gościa.
     * @param rezerwacja rezerwacja do przypisania
     */
    public void setRezerwacja(Rezerwacja rezerwacja) {
        this.rezerwacja = rezerwacja;
    }
    
    /**
     * Pobiera pełne imię i nazwisko gościa.
     * @return pełne imię i nazwisko
     */
    public String getPelneNazwisko() {
        return imie + " " + nazwisko;
    }
    
    @Override
    public String toString() {
        return "Gosc{" +
                "id=" + id +
                ", imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Gosc gosc = (Gosc) o;
        return id == gosc.id;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}
