package pl.pwr.hotel.controller;

import pl.pwr.hotel.entity.Gosc;
import pl.pwr.hotel.model.HotelModel;
import pl.pwr.hotel.model.IHotelModel;

/**
 * Implementacja kontrolera gości.
 * Obsługuje operacje związane z zarządzaniem profilami gości.
 */
public class GoscieKontroler implements IGoscieKontroler {
    
    private final IHotelModel model;
    
    /**
     * Konstruktor z wstrzykiwaniem modelu.
     * @param model model hotelowy
     */
    public GoscieKontroler(IHotelModel model) {
        this.model = model;
    }
    
    @Override
    public Gosc przegladProfiluGoscia(int goscId) {
        Gosc gosc = model.znajdzProfilGoscia(goscId);
        if (gosc == null) {
            throw new IllegalArgumentException("Gość o podanym ID nie istnieje: " + goscId);
        }
        return gosc;
    }
    
    @Override
    public Gosc edytujProfilGoscia(int goscId, String noweImie, String noweNazwisko, String nowyEmail) {
        Gosc gosc = model.znajdzProfilGoscia(goscId);
        if (gosc == null) {
            throw new IllegalArgumentException("Gość o podanym ID nie istnieje: " + goscId);
        }
        
        // Aktualizacja tylko niepustych pól
        if (noweImie != null && !noweImie.trim().isEmpty()) {
            gosc.setImie(noweImie.trim());
        }
        if (noweNazwisko != null && !noweNazwisko.trim().isEmpty()) {
            gosc.setNazwisko(noweNazwisko.trim());
        }
        if (nowyEmail != null && !nowyEmail.trim().isEmpty()) {
            if (!nowyEmail.contains("@")) {
                throw new IllegalArgumentException("Nieprawidłowy adres email");
            }
            gosc.setEmail(nowyEmail.trim().toLowerCase());
        }
        
        // Aktualizacja w DAO (poprzez model)
        if (model instanceof HotelModel hotelModel) {
            hotelModel.getGoscieDAO().aktualizuj(gosc);
        }
        
        return gosc;
    }
    
    @Override
    public Gosc utworzProfilGoscia(String imie, String nazwisko, String email) {
        // Walidacja
        if (imie == null || imie.trim().isEmpty()) {
            throw new IllegalArgumentException("Imię nie może być puste");
        }
        if (nazwisko == null || nazwisko.trim().isEmpty()) {
            throw new IllegalArgumentException("Nazwisko nie może być puste");
        }
        if (email == null || !email.contains("@")) {
            throw new IllegalArgumentException("Nieprawidłowy adres email");
        }
        
        return model.utworzProfilGoscia(imie, nazwisko, email);
    }
    
    /**
     * Pobiera pełne imię i nazwisko gościa.
     * @param goscId identyfikator gościa
     * @return pełne imię i nazwisko
     */
    public String pobierzPelneNazwisko(int goscId) {
        Gosc gosc = przegladProfiluGoscia(goscId);
        return gosc.getPelneNazwisko();
    }
}
