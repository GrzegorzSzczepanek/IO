package pl.pwr.hotel.controller;

import pl.pwr.hotel.entity.Rezerwacja;
import pl.pwr.hotel.model.IHotelModel;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Implementacja kontrolera rezerwacji.
 * Obsługuje operacje związane z zarządzaniem rezerwacjami.
 */
public class RezerwacjeKontroler implements IRezerwacjeKontroler {
    
    private final IHotelModel model;
    private static final double PROCENT_KARY_ZA_ANULOWANIE = 0.20; // 20% kary
    
    /**
     * Konstruktor z wstrzykiwaniem modelu.
     * @param model model hotelowy
     */
    public RezerwacjeKontroler(IHotelModel model) {
        this.model = model;
    }
    
    @Override
    public Rezerwacja utworzRezerwacje(int goscId, int pokojNumer, LocalDate dataOd, LocalDate dataDo) {
        return model.utworzRezerwacje(goscId, pokojNumer, dataOd, dataDo);
    }
    
    @Override
    public boolean anulujRezerwacje(int rezerwacjaId) {
        return model.anulujRezerwacje(rezerwacjaId);
    }
    
    @Override
    public Rezerwacja modyfikujRezerwacje(int rezerwacjaId, LocalDate nowaDataOd, LocalDate nowaDataDo) {
        return model.modyfikujRezerwacje(rezerwacjaId, nowaDataOd, nowaDataDo);
    }
    
    @Override
    public List<Rezerwacja> przegladajZarezerwowanePokoje(LocalDate dataOd, LocalDate dataDo) {
        return model.znajdzRezerwacje(dataOd, dataDo);
    }
    
    @Override
    public double pobierzOplateZaAnulowanie(int rezerwacjaId) {
        double pelnaOplata = model.pobierzOplate(rezerwacjaId);
        return pelnaOplata * PROCENT_KARY_ZA_ANULOWANIE;
    }
    
    /**
     * Oblicza opłatę za anulowanie w zależności od czasu do rozpoczęcia rezerwacji.
     * @param rezerwacjaId identyfikator rezerwacji
     * @return kwota opłaty za anulowanie
     */
    public double obliczOplateZaAnulowanieZTerminem(int rezerwacjaId) {
        List<Rezerwacja> rezerwacje = model.znajdzRezerwacje(null, null);
        Rezerwacja rezerwacja = rezerwacje.stream()
                .filter(r -> r.getId() == rezerwacjaId)
                .findFirst()
                .orElse(null);
        
        if (rezerwacja == null) {
            throw new IllegalArgumentException("Rezerwacja nie istnieje");
        }
        
        double pelnaOplata = model.pobierzOplate(rezerwacjaId);
        long dniDoRozpoczecia = ChronoUnit.DAYS.between(LocalDate.now(), rezerwacja.getDataOd());
        
        // Polityka anulowania:
        // - Ponad 7 dni przed: bez opłaty
        // - 3-7 dni przed: 20% opłaty
        // - 1-3 dni przed: 50% opłaty
        // - Mniej niż 1 dzień: 100% opłaty
        if (dniDoRozpoczecia > 7) {
            return 0.0;
        } else if (dniDoRozpoczecia >= 3) {
            return pelnaOplata * 0.20;
        } else if (dniDoRozpoczecia >= 1) {
            return pelnaOplata * 0.50;
        } else {
            return pelnaOplata;
        }
    }
}
