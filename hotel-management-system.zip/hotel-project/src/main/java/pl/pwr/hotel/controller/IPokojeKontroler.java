package pl.pwr.hotel.controller;

import pl.pwr.hotel.entity.Pokoj;
import java.time.LocalDate;
import java.util.List;

/**
 * Interfejs kontrolera pokoi.
 * Definiuje operacje związane z zarządzaniem pokojami.
 */
public interface IPokojeKontroler {
    
    /**
     * Wyszukuje dostępne pokoje w danym terminie.
     * @param dataOd data rozpoczęcia
     * @param dataDo data zakończenia
     * @return lista dostępnych pokoi
     */
    List<Pokoj> wyszukajDostepnePokoje(LocalDate dataOd, LocalDate dataDo);
    
    /**
     * Przypisuje pokój do gościa (rezerwacji).
     * @param pokojNumer numer pokoju
     * @param goscId identyfikator gościa
     * @return true jeśli przypisano pomyślnie
     */
    boolean przypiszPokoj(int pokojNumer, int goscId);
    
    /**
     * Aktualizuje status pokoju.
     * @param pokojNumer numer pokoju
     * @param nowyStatus nowy status
     * @return true jeśli zaktualizowano pomyślnie
     */
    boolean aktualizujStatusPokoju(int pokojNumer, Pokoj.StatusPokoju nowyStatus);
    
    /**
     * Oznacza pokój jako posprzątany.
     * @param pokojNumer numer pokoju
     * @return true jeśli operacja udana
     */
    boolean sprzatanie(int pokojNumer);
    
    /**
     * Zgłasza usterkę w pokoju.
     * @param pokojNumer numer pokoju
     * @param opisUsterki opis usterki
     * @return true jeśli zgłoszono pomyślnie
     */
    boolean zglosUsterke(int pokojNumer, String opisUsterki);
    
    /**
     * Zarządza inwentarzem pokoju.
     * @param pokojNumer numer pokoju
     * @param elementy lista elementów inwentarza
     * @return true jeśli zaktualizowano pomyślnie
     */
    boolean zarzadzajInwentarzem(int pokojNumer, List<String> elementy);
}
