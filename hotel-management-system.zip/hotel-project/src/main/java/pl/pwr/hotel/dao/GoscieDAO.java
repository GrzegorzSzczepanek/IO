package pl.pwr.hotel.dao;

import pl.pwr.hotel.entity.Gosc;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementacja DAO dla encji Gosc.
 * Przechowuje dane w pamięci (symulacja bazy danych).
 */
public class GoscieDAO implements IDAO<Gosc> {
    
    private final Map<Integer, Gosc> goscie;
    private int nextId;
    
    /**
     * Konstruktor domyślny.
     */
    public GoscieDAO() {
        this.goscie = new HashMap<>();
        this.nextId = 1;
    }
    
    @Override
    public Gosc pobierz(int id) {
        return goscie.get(id);
    }
    
    @Override
    public void zapisz(Gosc gosc) {
        if (gosc != null) {
            if (gosc.getId() == 0) {
                gosc.setId(nextId++);
            }
            goscie.put(gosc.getId(), gosc);
        }
    }
    
    @Override
    public boolean usun(int id) {
        return goscie.remove(id) != null;
    }
    
    @Override
    public List<Gosc> pobierzWszystkie() {
        return new ArrayList<>(goscie.values());
    }
    
    @Override
    public void aktualizuj(Gosc gosc) {
        if (gosc != null && goscie.containsKey(gosc.getId())) {
            goscie.put(gosc.getId(), gosc);
        }
    }
    
    /**
     * Wyszukuje gościa po adresie email.
     * @param email adres email
     * @return gość lub null jeśli nie znaleziono
     */
    public Gosc znajdzPoEmail(String email) {
        return goscie.values().stream()
                .filter(g -> g.getEmail() != null && g.getEmail().equals(email))
                .findFirst()
                .orElse(null);
    }
    
    /**
     * Wyszukuje gości po nazwisku.
     * @param nazwisko nazwisko do wyszukania
     * @return lista gości o podanym nazwisku
     */
    public List<Gosc> znajdzPoNazwisku(String nazwisko) {
        return goscie.values().stream()
                .filter(g -> g.getNazwisko() != null && g.getNazwisko().equalsIgnoreCase(nazwisko))
                .toList();
    }
    
    /**
     * Zwraca liczbę gości w systemie.
     * @return liczba gości
     */
    public int liczbaGosci() {
        return goscie.size();
    }
    
    /**
     * Czyści wszystkich gości.
     */
    public void wyczyscWszystko() {
        goscie.clear();
        nextId = 1;
    }
}
