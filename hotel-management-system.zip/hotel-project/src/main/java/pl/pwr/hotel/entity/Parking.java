package pl.pwr.hotel.entity;

/**
 * Klasa reprezentująca dodatek parkingowy do rezerwacji.
 * Implementuje interfejs IDodatek.
 */
public class Parking implements IDodatek {
    
    private double cena;
    private String typMiejsca;
    
    /**
     * Konstruktor domyślny - standardowe miejsce parkingowe.
     */
    public Parking() {
        this.cena = 30.0;
        this.typMiejsca = "zewnętrzne";
    }
    
    /**
     * Konstruktor z ceną.
     * @param cena cena parkingu za dobę
     */
    public Parking(double cena) {
        this.cena = cena;
        this.typMiejsca = "zewnętrzne";
    }
    
    /**
     * Konstruktor pełny.
     * @param cena cena parkingu za dobę
     * @param typMiejsca typ miejsca (np. "zewnętrzne", "podziemne", "zadaszone")
     */
    public Parking(double cena, String typMiejsca) {
        this.cena = cena;
        this.typMiejsca = typMiejsca;
    }
    
    @Override
    public double obliczDodatkowyKoszt() {
        return cena;
    }
    
    @Override
    public String getOpis() {
        return "Parking " + typMiejsca + " - " + cena + " PLN/dzień";
    }
    
    /**
     * Pobiera cenę parkingu.
     * @return cena parkingu
     */
    public double getCena() {
        return cena;
    }
    
    /**
     * Ustawia cenę parkingu.
     * @param cena nowa cena
     */
    public void setCena(double cena) {
        this.cena = cena;
    }
    
    /**
     * Pobiera typ miejsca parkingowego.
     * @return typ miejsca
     */
    public String getTypMiejsca() {
        return typMiejsca;
    }
    
    /**
     * Ustawia typ miejsca parkingowego.
     * @param typMiejsca typ miejsca
     */
    public void setTypMiejsca(String typMiejsca) {
        this.typMiejsca = typMiejsca;
    }
    
    @Override
    public String toString() {
        return "Parking{" +
                "cena=" + cena +
                ", typMiejsca='" + typMiejsca + '\'' +
                '}';
    }
}
