package pl.pwr.hotel.entity;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * Klasa encji reprezentująca rezerwację hotelową.
 * Warstwa encji - Model w MVC.
 */
public class Rezerwacja {
    
    private int id;
    private LocalDate dataOd;
    private LocalDate dataDo;
    private Pokoj pokoj;
    private Gosc gosc;
    private List<IDodatek> dodatki;
    private StatusRezerwacji status;
    
    /**
     * Enum reprezentujący status rezerwacji.
     */
    public enum StatusRezerwacji {
        NOWA,
        POTWIERDZONA,
        ZAMELDOWANA,
        WYMELDOWANA,
        ANULOWANA
    }
    
    /**
     * Konstruktor domyślny.
     */
    public Rezerwacja() {
        this.dodatki = new ArrayList<>();
        this.status = StatusRezerwacji.NOWA;
    }
    
    /**
     * Konstruktor z parametrami.
     * @param id identyfikator rezerwacji
     * @param dataOd data rozpoczęcia
     * @param dataDo data zakończenia
     * @param pokoj zarezerwowany pokój
     * @param gosc gość dokonujący rezerwacji
     */
    public Rezerwacja(int id, LocalDate dataOd, LocalDate dataDo, Pokoj pokoj, Gosc gosc) {
        this.id = id;
        this.dataOd = dataOd;
        this.dataDo = dataDo;
        this.pokoj = pokoj;
        this.gosc = gosc;
        this.dodatki = new ArrayList<>();
        this.status = StatusRezerwacji.NOWA;
    }
    
    /**
     * Pobiera identyfikator rezerwacji.
     * @return identyfikator rezerwacji
     */
    public int getId() {
        return id;
    }
    
    /**
     * Ustawia identyfikator rezerwacji.
     * @param id identyfikator rezerwacji
     */
    public void setId(int id) {
        this.id = id;
    }
    
    /**
     * Pobiera datę rozpoczęcia rezerwacji.
     * @return data rozpoczęcia
     */
    public LocalDate getDataOd() {
        return dataOd;
    }
    
    /**
     * Ustawia datę rozpoczęcia rezerwacji.
     * @param dataOd data rozpoczęcia
     */
    public void setDataOd(LocalDate dataOd) {
        this.dataOd = dataOd;
    }
    
    /**
     * Pobiera datę zakończenia rezerwacji.
     * @return data zakończenia
     */
    public LocalDate getDataDo() {
        return dataDo;
    }
    
    /**
     * Ustawia datę zakończenia rezerwacji.
     * @param dataDo data zakończenia
     */
    public void setDataDo(LocalDate dataDo) {
        this.dataDo = dataDo;
    }
    
    /**
     * Pobiera pokój przypisany do rezerwacji.
     * @return pokój
     */
    public Pokoj getPokoj() {
        return pokoj;
    }
    
    /**
     * Ustawia pokój dla rezerwacji.
     * @param pokoj pokój do przypisania
     */
    public void setPokoj(Pokoj pokoj) {
        this.pokoj = pokoj;
    }
    
    /**
     * Pobiera gościa przypisanego do rezerwacji.
     * @return gość
     */
    public Gosc getGosc() {
        return gosc;
    }
    
    /**
     * Ustawia gościa dla rezerwacji.
     * @param gosc gość do przypisania
     */
    public void setGosc(Gosc gosc) {
        this.gosc = gosc;
    }
    
    /**
     * Pobiera status rezerwacji.
     * @return status rezerwacji
     */
    public StatusRezerwacji getStatus() {
        return status;
    }
    
    /**
     * Ustawia status rezerwacji.
     * @param status nowy status
     */
    public void setStatus(StatusRezerwacji status) {
        this.status = status;
    }
    
    /**
     * Oblicza całkowitą cenę rezerwacji.
     * Uwzględnia cenę pokoju oraz wszystkie dodatki.
     * @return całkowita cena rezerwacji
     */
    public double obliczCene() {
        if (pokoj == null || dataOd == null || dataDo == null) {
            return 0.0;
        }
        
        long liczbaDni = ChronoUnit.DAYS.between(dataOd, dataDo);
        if (liczbaDni <= 0) {
            return 0.0;
        }
        
        // Cena bazowa za pokój
        double cenaCalkowita = pokoj.getCenaBazowa() * liczbaDni;
        
        // Dodanie kosztów dodatków
        for (IDodatek dodatek : dodatki) {
            cenaCalkowita += dodatek.obliczDodatkowyKoszt() * liczbaDni;
        }
        
        return cenaCalkowita;
    }
    
    /**
     * Oblicza liczbę dni rezerwacji.
     * @return liczba dni
     */
    public long obliczLiczbeDni() {
        if (dataOd == null || dataDo == null) {
            return 0;
        }
        return ChronoUnit.DAYS.between(dataOd, dataDo);
    }
    
    /**
     * Dodaje dodatek do rezerwacji.
     * @param dodatek dodatek do dodania
     */
    public void dodajDodatek(IDodatek dodatek) {
        if (dodatek != null) {
            dodatki.add(dodatek);
        }
    }
    
    /**
     * Usuwa dodatek z rezerwacji.
     * @param dodatek dodatek do usunięcia
     * @return true jeśli dodatek został usunięty
     */
    public boolean usunDodatek(IDodatek dodatek) {
        return dodatki.remove(dodatek);
    }
    
    /**
     * Pobiera listę dodatków.
     * @return lista dodatków
     */
    public List<IDodatek> pobierzDodatki() {
        return new ArrayList<>(dodatki);
    }
    
    /**
     * Sprawdza czy rezerwacja zawiera dany typ dodatku.
     * @param klasaDodatku klasa dodatku do sprawdzenia
     * @return true jeśli rezerwacja zawiera dodatek danego typu
     */
    public boolean maTypDodatku(Class<? extends IDodatek> klasaDodatku) {
        return dodatki.stream().anyMatch(d -> klasaDodatku.isInstance(d));
    }
    
    /**
     * Czyści wszystkie dodatki.
     */
    public void wyczyscDodatki() {
        dodatki.clear();
    }
    
    @Override
    public String toString() {
        return "Rezerwacja{" +
                "id=" + id +
                ", dataOd=" + dataOd +
                ", dataDo=" + dataDo +
                ", pokoj=" + (pokoj != null ? pokoj.getNumer() : "brak") +
                ", gosc=" + (gosc != null ? gosc.getPelneNazwisko() : "brak") +
                ", status=" + status +
                ", liczbaDodatkow=" + dodatki.size() +
                '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Rezerwacja that = (Rezerwacja) o;
        return id == that.id;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}
