package pl.pwr.hotel.model;

import pl.pwr.hotel.dao.GoscieDAO;
import pl.pwr.hotel.dao.PokojeDAO;
import pl.pwr.hotel.dao.RezerwacjeDAO;
import pl.pwr.hotel.entity.Gosc;
import pl.pwr.hotel.entity.Pokoj;
import pl.pwr.hotel.entity.Rezerwacja;
import pl.pwr.hotel.factory.IGoscFactory;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Implementacja modelu hotelowego.
 * Centralny punkt dostępu do logiki biznesowej systemu.
 */
public class HotelModel implements IHotelModel {
    
    private final RezerwacjeDAO rezerwacjeDAO;
    private final PokojeDAO pokojeDAO;
    private final GoscieDAO goscieDAO;
    private final IGoscFactory fabrykaGosci;
    
    /**
     * Konstruktor z wstrzykiwaniem zależności.
     * @param rezerwacjeDAO DAO rezerwacji
     * @param pokojeDAO DAO pokoi
     * @param goscieDAO DAO gości
     * @param fabrykaGosci fabryka gości
     */
    public HotelModel(RezerwacjeDAO rezerwacjeDAO, PokojeDAO pokojeDAO, 
                      GoscieDAO goscieDAO, IGoscFactory fabrykaGosci) {
        this.rezerwacjeDAO = rezerwacjeDAO;
        this.pokojeDAO = pokojeDAO;
        this.goscieDAO = goscieDAO;
        this.fabrykaGosci = fabrykaGosci;
    }
    
    @Override
    public Rezerwacja utworzRezerwacje(int goscId, int pokojNumer, LocalDate dataOd, LocalDate dataDo) {
        // Walidacja dat
        if (dataOd == null || dataDo == null) {
            throw new IllegalArgumentException("Daty rezerwacji nie mogą być null");
        }
        if (!dataOd.isBefore(dataDo)) {
            throw new IllegalArgumentException("Data rozpoczęcia musi być przed datą zakończenia");
        }
        if (dataOd.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Data rozpoczęcia nie może być w przeszłości");
        }
        
        // Sprawdzenie czy gość istnieje
        Gosc gosc = goscieDAO.pobierz(goscId);
        if (gosc == null) {
            throw new IllegalArgumentException("Gość o podanym ID nie istnieje: " + goscId);
        }
        
        // Sprawdzenie czy pokój istnieje
        Pokoj pokoj = pokojeDAO.pobierz(pokojNumer);
        if (pokoj == null) {
            throw new IllegalArgumentException("Pokój o podanym numerze nie istnieje: " + pokojNumer);
        }
        
        // Sprawdzenie dostępności pokoju
        if (!rezerwacjeDAO.czyPokojDostepny(pokojNumer, dataOd, dataDo)) {
            throw new IllegalStateException("Pokój nie jest dostępny w podanym terminie");
        }
        
        // Utworzenie rezerwacji
        Rezerwacja rezerwacja = new Rezerwacja(0, dataOd, dataDo, pokoj, gosc);
        rezerwacja.setStatus(Rezerwacja.StatusRezerwacji.NOWA);
        rezerwacjeDAO.zapisz(rezerwacja);
        
        return rezerwacja;
    }
    
    @Override
    public boolean anulujRezerwacje(int rezerwacjaId) {
        Rezerwacja rezerwacja = rezerwacjeDAO.pobierz(rezerwacjaId);
        if (rezerwacja == null) {
            return false;
        }
        
        // Sprawdzenie czy rezerwację można anulować
        if (rezerwacja.getStatus() == Rezerwacja.StatusRezerwacji.ANULOWANA) {
            return false;
        }
        if (rezerwacja.getStatus() == Rezerwacja.StatusRezerwacji.WYMELDOWANA) {
            return false;
        }
        
        rezerwacja.setStatus(Rezerwacja.StatusRezerwacji.ANULOWANA);
        rezerwacjeDAO.aktualizuj(rezerwacja);
        return true;
    }
    
    @Override
    public Rezerwacja modyfikujRezerwacje(int rezerwacjaId, LocalDate nowaDataOd, LocalDate nowaDataDo) {
        Rezerwacja rezerwacja = rezerwacjeDAO.pobierz(rezerwacjaId);
        if (rezerwacja == null) {
            throw new IllegalArgumentException("Rezerwacja o podanym ID nie istnieje: " + rezerwacjaId);
        }
        
        // Sprawdzenie czy rezerwację można modyfikować
        if (rezerwacja.getStatus() == Rezerwacja.StatusRezerwacji.ANULOWANA ||
            rezerwacja.getStatus() == Rezerwacja.StatusRezerwacji.WYMELDOWANA) {
            throw new IllegalStateException("Nie można modyfikować anulowanej lub zakończonej rezerwacji");
        }
        
        // Walidacja dat
        if (nowaDataOd != null && nowaDataDo != null && !nowaDataOd.isBefore(nowaDataDo)) {
            throw new IllegalArgumentException("Data rozpoczęcia musi być przed datą zakończenia");
        }
        
        // Sprawdzenie dostępności pokoju w nowym terminie
        LocalDate dataOdDoSprawdzenia = nowaDataOd != null ? nowaDataOd : rezerwacja.getDataOd();
        LocalDate dataDoDoSprawdzenia = nowaDataDo != null ? nowaDataDo : rezerwacja.getDataDo();
        
        // Tymczasowo anuluj rezerwację aby sprawdzić dostępność
        List<Rezerwacja> konfliktujace = rezerwacjeDAO.pobierzDlaPokoju(rezerwacja.getPokoj().getNumer())
                .stream()
                .filter(r -> r.getId() != rezerwacjaId)
                .filter(r -> r.getStatus() != Rezerwacja.StatusRezerwacji.ANULOWANA)
                .filter(r -> !r.getDataDo().isBefore(dataOdDoSprawdzenia) && !r.getDataOd().isAfter(dataDoDoSprawdzenia))
                .toList();
        
        if (!konfliktujace.isEmpty()) {
            throw new IllegalStateException("Pokój nie jest dostępny w nowym terminie");
        }
        
        // Aktualizacja dat
        if (nowaDataOd != null) {
            rezerwacja.setDataOd(nowaDataOd);
        }
        if (nowaDataDo != null) {
            rezerwacja.setDataDo(nowaDataDo);
        }
        
        rezerwacjeDAO.aktualizuj(rezerwacja);
        return rezerwacja;
    }
    
    @Override
    public List<Rezerwacja> znajdzRezerwacje(LocalDate dataOd, LocalDate dataDo) {
        if (dataOd == null && dataDo == null) {
            return rezerwacjeDAO.pobierzWszystkie();
        }
        
        LocalDate skutecznaDataOd = dataOd != null ? dataOd : LocalDate.MIN;
        LocalDate skutecznaDataDo = dataDo != null ? dataDo : LocalDate.MAX;
        
        return rezerwacjeDAO.pobierzWOkresie(skutecznaDataOd, skutecznaDataDo);
    }
    
    @Override
    public List<Pokoj> znajdzDostepnePokoje(LocalDate dataOd, LocalDate dataDo) {
        if (dataOd == null || dataDo == null) {
            throw new IllegalArgumentException("Daty nie mogą być null");
        }
        
        return pokojeDAO.pobierzWszystkie().stream()
                .filter(p -> rezerwacjeDAO.czyPokojDostepny(p.getNumer(), dataOd, dataDo))
                .collect(Collectors.toList());
    }
    
    @Override
    public boolean aktualizujStatusPokoju(int numerPokoju, Pokoj.StatusPokoju nowyStatus) {
        Pokoj pokoj = pokojeDAO.pobierz(numerPokoju);
        if (pokoj == null) {
            return false;
        }
        
        pokoj.setStatus(nowyStatus);
        pokojeDAO.aktualizuj(pokoj);
        return true;
    }
    
    @Override
    public Gosc utworzProfilGoscia(String imie, String nazwisko, String email) {
        // Sprawdzenie czy gość z takim emailem już istnieje
        Gosc istniejacy = goscieDAO.znajdzPoEmail(email);
        if (istniejacy != null) {
            throw new IllegalStateException("Gość z podanym adresem email już istnieje");
        }
        
        Gosc nowyGosc = fabrykaGosci.utworzGoscia(imie, nazwisko, email);
        goscieDAO.zapisz(nowyGosc);
        return nowyGosc;
    }
    
    @Override
    public Gosc znajdzProfilGoscia(int goscId) {
        return goscieDAO.pobierz(goscId);
    }
    
    @Override
    public double pobierzOplate(int rezerwacjaId) {
        Rezerwacja rezerwacja = rezerwacjeDAO.pobierz(rezerwacjaId);
        if (rezerwacja == null) {
            throw new IllegalArgumentException("Rezerwacja o podanym ID nie istnieje: " + rezerwacjaId);
        }
        
        return rezerwacja.obliczCene();
    }
    
    @Override
    public boolean potwierdzPlatnosc(int rezerwacjaId) {
        Rezerwacja rezerwacja = rezerwacjeDAO.pobierz(rezerwacjaId);
        if (rezerwacja == null) {
            return false;
        }
        
        if (rezerwacja.getStatus() == Rezerwacja.StatusRezerwacji.NOWA) {
            rezerwacja.setStatus(Rezerwacja.StatusRezerwacji.POTWIERDZONA);
            rezerwacjeDAO.aktualizuj(rezerwacja);
            return true;
        }
        
        return false;
    }
    
    // ========== Metody pomocnicze ==========
    
    /**
     * Zameldowuje gościa (zmienia status rezerwacji).
     * @param rezerwacjaId identyfikator rezerwacji
     * @return true jeśli zameldowano pomyślnie
     */
    public boolean zameldujGoscia(int rezerwacjaId) {
        Rezerwacja rezerwacja = rezerwacjeDAO.pobierz(rezerwacjaId);
        if (rezerwacja == null) {
            return false;
        }
        
        if (rezerwacja.getStatus() != Rezerwacja.StatusRezerwacji.POTWIERDZONA &&
            rezerwacja.getStatus() != Rezerwacja.StatusRezerwacji.NOWA) {
            return false;
        }
        
        rezerwacja.setStatus(Rezerwacja.StatusRezerwacji.ZAMELDOWANA);
        rezerwacjeDAO.aktualizuj(rezerwacja);
        
        // Zmiana statusu pokoju
        if (rezerwacja.getPokoj() != null) {
            rezerwacja.getPokoj().setStatus(Pokoj.StatusPokoju.ZAJETY);
            pokojeDAO.aktualizuj(rezerwacja.getPokoj());
        }
        
        return true;
    }
    
    /**
     * Wymeldowuje gościa (zmienia status rezerwacji).
     * @param rezerwacjaId identyfikator rezerwacji
     * @return true jeśli wymeldowano pomyślnie
     */
    public boolean wymeldujGoscia(int rezerwacjaId) {
        Rezerwacja rezerwacja = rezerwacjeDAO.pobierz(rezerwacjaId);
        if (rezerwacja == null) {
            return false;
        }
        
        if (rezerwacja.getStatus() != Rezerwacja.StatusRezerwacji.ZAMELDOWANA) {
            return false;
        }
        
        rezerwacja.setStatus(Rezerwacja.StatusRezerwacji.WYMELDOWANA);
        rezerwacjeDAO.aktualizuj(rezerwacja);
        
        // Zmiana statusu pokoju na "do sprzątania"
        if (rezerwacja.getPokoj() != null) {
            rezerwacja.getPokoj().setStatus(Pokoj.StatusPokoju.W_SPRZATANIU);
            pokojeDAO.aktualizuj(rezerwacja.getPokoj());
        }
        
        return true;
    }
    
    /**
     * Pobiera DAO rezerwacji.
     * @return DAO rezerwacji
     */
    public RezerwacjeDAO getRezerwacjeDAO() {
        return rezerwacjeDAO;
    }
    
    /**
     * Pobiera DAO pokoi.
     * @return DAO pokoi
     */
    public PokojeDAO getPokojeDAO() {
        return pokojeDAO;
    }
    
    /**
     * Pobiera DAO gości.
     * @return DAO gości
     */
    public GoscieDAO getGoscieDAO() {
        return goscieDAO;
    }
}
