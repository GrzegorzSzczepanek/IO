package pl.pwr.hotel.entity;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Testy jednostkowe dla klasy Rezerwacja.
 * Zadanie 1: Testy bez mockowania - testowanie operacji niezależnych i zależnych.
 * 
 * Wymagania spełnione:
 * - @DisplayName dla wszystkich testów
 * - @Order do określenia kolejności
 * - @BeforeEach i @AfterEach
 * - Minimum 3 różne asercje
 * - 2 metody parametryzacji (@MethodSource, @ValueSource)
 */
@DisplayName("Testy jednostkowe klasy Rezerwacja")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Tag("entity")
class RezerwacjaTest {
    
    private Rezerwacja rezerwacja;
    private Pokoj pokoj;
    private Gosc gosc;
    
    @BeforeEach
    void setUp() {
        // Przygotowanie obiektów testowych
        pokoj = new Pokoj(101, "dwuosobowy", 200.0);
        gosc = new Gosc(1, "Jan", "Kowalski", "jan@email.pl");
        rezerwacja = new Rezerwacja(
            1, 
            LocalDate.of(2025, 6, 1), 
            LocalDate.of(2025, 6, 5), 
            pokoj, 
            gosc
        );
    }
    
    @AfterEach
    void tearDown() {
        rezerwacja = null;
        pokoj = null;
        gosc = null;
    }
    
    // ========== Testy konstruktorów ==========
    
    @Test
    @Order(1)
    @DisplayName("Konstruktor domyślny powinien utworzyć rezerwację ze statusem NOWA")
    void konstruktorDomyslny_powinienUtworzycRezerwacjeZeStatusemNowa() {
        // when
        Rezerwacja nowa = new Rezerwacja();
        
        // then
        assertAll("Wartości domyślne",
            () -> assertEquals(0, nowa.getId()),
            () -> assertEquals(Rezerwacja.StatusRezerwacji.NOWA, nowa.getStatus()),
            () -> assertNotNull(nowa.pobierzDodatki()),
            () -> assertTrue(nowa.pobierzDodatki().isEmpty())
        );
    }
    
    @Test
    @Order(2)
    @DisplayName("Konstruktor z parametrami powinien poprawnie ustawić wszystkie pola")
    void konstruktorZParametrami_powinienPoprawnieUstawicPola() {
        // then
        assertAll("Wartości z konstruktora",
            () -> assertEquals(1, rezerwacja.getId()),
            () -> assertEquals(LocalDate.of(2025, 6, 1), rezerwacja.getDataOd()),
            () -> assertEquals(LocalDate.of(2025, 6, 5), rezerwacja.getDataDo()),
            () -> assertEquals(pokoj, rezerwacja.getPokoj()),
            () -> assertEquals(gosc, rezerwacja.getGosc()),
            () -> assertEquals(Rezerwacja.StatusRezerwacji.NOWA, rezerwacja.getStatus())
        );
    }
    
    // ========== Testy obliczania ceny ==========
    
    @Test
    @Order(3)
    @DisplayName("obliczCene powinno zwrócić poprawną cenę za 4 noce")
    void obliczCene_powinnoZwrocicPoprawnaCeneZa4Noce() {
        // Pokój kosztuje 200 PLN/noc, 4 noce = 800 PLN
        // when
        double cena = rezerwacja.obliczCene();
        
        // then
        assertEquals(800.0, cena, 0.01);
    }
    
    @Test
    @Order(4)
    @DisplayName("obliczCene powinno uwzględniać dodatki")
    void obliczCene_powinnoUwzgledniacDodatki() {
        // given - dodajemy śniadanie (50 PLN/dzień) i parking (30 PLN/dzień)
        rezerwacja.dodajDodatek(new Sniadanie(50.0));
        rezerwacja.dodajDodatek(new Parking(30.0));
        
        // when - 4 noce * (200 + 50 + 30) = 4 * 280 = 1120
        double cena = rezerwacja.obliczCene();
        
        // then
        assertEquals(1120.0, cena, 0.01);
    }
    
    @Test
    @Order(5)
    @DisplayName("obliczCene powinno zwrócić 0 gdy brak pokoju")
    void obliczCene_powinnoZwrocic0GdyBrakPokoju() {
        // given
        rezerwacja.setPokoj(null);
        
        // when
        double cena = rezerwacja.obliczCene();
        
        // then
        assertEquals(0.0, cena);
    }
    
    @Test
    @Order(6)
    @DisplayName("obliczCene powinno zwrócić 0 gdy brak dat")
    void obliczCene_powinnoZwrocic0GdyBrakDat() {
        // given
        rezerwacja.setDataOd(null);
        
        // when
        double cena = rezerwacja.obliczCene();
        
        // then
        assertEquals(0.0, cena);
    }
    
    @ParameterizedTest
    @Order(7)
    @DisplayName("obliczCene powinno poprawnie liczyć dla różnych długości pobytu")
    @MethodSource("dostawcaDanychDlugosciPobytu")
    void obliczCene_powinnoPoprawnieLiczycDlaRoznychDlugosciPobytu(
            LocalDate dataOd, LocalDate dataDo, double oczekiwanaCena) {
        // given
        rezerwacja.setDataOd(dataOd);
        rezerwacja.setDataDo(dataDo);
        
        // when
        double cena = rezerwacja.obliczCene();
        
        // then
        assertEquals(oczekiwanaCena, cena, 0.01);
    }
    
    static Stream<Arguments> dostawcaDanychDlugosciPobytu() {
        return Stream.of(
            Arguments.of(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 1, 2), 200.0),  // 1 noc
            Arguments.of(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 1, 8), 1400.0), // 7 nocy
            Arguments.of(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 1, 15), 2800.0) // 14 nocy
        );
    }
    
    // ========== Testy liczby dni ==========
    
    @Test
    @Order(8)
    @DisplayName("obliczLiczbeDni powinno zwrócić poprawną liczbę dni")
    void obliczLiczbeDni_powinnoZwrocicPoprawnaLiczbeDni() {
        // when
        long liczbaDni = rezerwacja.obliczLiczbeDni();
        
        // then
        assertEquals(4, liczbaDni);
    }
    
    @Test
    @Order(9)
    @DisplayName("obliczLiczbeDni powinno zwrócić 0 gdy brak dat")
    void obliczLiczbeDni_powinnoZwrocic0GdyBrakDat() {
        // given
        rezerwacja.setDataOd(null);
        
        // when
        long liczbaDni = rezerwacja.obliczLiczbeDni();
        
        // then
        assertEquals(0, liczbaDni);
    }
    
    // ========== Testy dodatków ==========
    
    @Test
    @Order(10)
    @DisplayName("dodajDodatek powinno dodać dodatek do listy")
    void dodajDodatek_powinnoDodacDodatekDoListy() {
        // given
        Sniadanie sniadanie = new Sniadanie(50.0);
        
        // when
        rezerwacja.dodajDodatek(sniadanie);
        
        // then
        List<IDodatek> dodatki = rezerwacja.pobierzDodatki();
        assertAll(
            () -> assertEquals(1, dodatki.size()),
            () -> assertTrue(dodatki.contains(sniadanie))
        );
    }
    
    @Test
    @Order(11)
    @DisplayName("dodajDodatek nie powinno dodawać null")
    void dodajDodatek_niePowinnoDoawacNull() {
        // when
        rezerwacja.dodajDodatek(null);
        
        // then
        assertTrue(rezerwacja.pobierzDodatki().isEmpty());
    }
    
    @Test
    @Order(12)
    @DisplayName("usunDodatek powinno usunąć istniejący dodatek")
    void usunDodatek_powinnoUsunacIstniejacyDodatek() {
        // given
        Sniadanie sniadanie = new Sniadanie(50.0);
        rezerwacja.dodajDodatek(sniadanie);
        
        // when
        boolean wynik = rezerwacja.usunDodatek(sniadanie);
        
        // then
        assertAll(
            () -> assertTrue(wynik),
            () -> assertTrue(rezerwacja.pobierzDodatki().isEmpty())
        );
    }
    
    @Test
    @Order(13)
    @DisplayName("usunDodatek powinno zwrócić false dla nieistniejącego dodatku")
    void usunDodatek_powinnoZwrocicFalseDlaNieistniejacegoDodatku() {
        // given
        Sniadanie sniadanie = new Sniadanie(50.0);
        
        // when
        boolean wynik = rezerwacja.usunDodatek(sniadanie);
        
        // then
        assertFalse(wynik);
    }
    
    @ParameterizedTest
    @Order(14)
    @DisplayName("maTypDodatku powinno sprawdzać typ dodatku")
    @ValueSource(classes = {Sniadanie.class, Parking.class})
    void maTypDodatku_powinnoSprawdzacTypDodatku(Class<? extends IDodatek> klasaDodatku) {
        // given - na początku brak dodatków
        assertFalse(rezerwacja.maTypDodatku(klasaDodatku));
        
        // when - dodajemy odpowiedni typ
        if (klasaDodatku == Sniadanie.class) {
            rezerwacja.dodajDodatek(new Sniadanie());
        } else {
            rezerwacja.dodajDodatek(new Parking());
        }
        
        // then
        assertTrue(rezerwacja.maTypDodatku(klasaDodatku));
    }
    
    @Test
    @Order(15)
    @DisplayName("wyczyscDodatki powinno usunąć wszystkie dodatki")
    void wyczyscDodatki_powinnoUsunacWszystkieDodatki() {
        // given
        rezerwacja.dodajDodatek(new Sniadanie());
        rezerwacja.dodajDodatek(new Parking());
        
        // when
        rezerwacja.wyczyscDodatki();
        
        // then
        assertTrue(rezerwacja.pobierzDodatki().isEmpty());
    }
    
    // ========== Testy statusu ==========
    
    @Test
    @Order(16)
    @DisplayName("Nowa rezerwacja powinna mieć status NOWA")
    void nowaRezerwacja_powinnaMiecStatusNowa() {
        // then
        assertEquals(Rezerwacja.StatusRezerwacji.NOWA, rezerwacja.getStatus());
    }
    
    @Test
    @Order(17)
    @DisplayName("setStatus powinno zmienić status rezerwacji")
    void setStatus_powinnoZmienicStatusRezerwacji() {
        // when
        rezerwacja.setStatus(Rezerwacja.StatusRezerwacji.POTWIERDZONA);
        
        // then
        assertEquals(Rezerwacja.StatusRezerwacji.POTWIERDZONA, rezerwacja.getStatus());
    }
    
    // ========== Testy equals i hashCode ==========
    
    @Test
    @Order(18)
    @DisplayName("Rezerwacje z tym samym ID powinny być równe")
    void equals_rezerwacjeZTymSamymId_powinnyBycRowne() {
        // given
        Rezerwacja inna = new Rezerwacja();
        inna.setId(1);
        
        // then
        assertEquals(rezerwacja, inna);
    }
    
    @Test
    @Order(19)
    @DisplayName("Rezerwacje z różnymi ID nie powinny być równe")
    void equals_rezerwacjeZRoznymiId_niePowinnyBycRowne() {
        // given
        Rezerwacja inna = new Rezerwacja();
        inna.setId(2);
        
        // then
        assertNotEquals(rezerwacja, inna);
    }
    
    @Test
    @Order(20)
    @DisplayName("toString powinno zawierać kluczowe informacje")
    void toString_powinnoZawieracKlucoweInformacje() {
        // when
        String wynik = rezerwacja.toString();
        
        // then
        assertAll("Zawartość toString",
            () -> assertTrue(wynik.contains("id=1")),
            () -> assertTrue(wynik.contains("dataOd=")),
            () -> assertTrue(wynik.contains("status="))
        );
    }
}
