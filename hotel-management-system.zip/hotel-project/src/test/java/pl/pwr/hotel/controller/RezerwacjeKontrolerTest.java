package pl.pwr.hotel.controller;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import pl.pwr.hotel.entity.Gosc;
import pl.pwr.hotel.entity.Pokoj;
import pl.pwr.hotel.entity.Rezerwacja;
import pl.pwr.hotel.model.IHotelModel;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Testy jednostkowe dla klasy RezerwacjeKontroler z użyciem Mockito.
 * Zadanie 2: Testy z mockowaniem zależności.
 * 
 * Wymagania spełnione:
 * - @Mock do tworzenia mocków
 * - @InjectMocks do wstrzykiwania mocków
 * - when().thenReturn() do konfiguracji zachowania
 * - verify() do sprawdzania wywołań
 * - @DisplayName, @Order, @BeforeEach/@AfterEach
 * - Minimum 3 różne asercje
 * - 2 metody parametryzacji (@CsvSource, @ValueSource)
 */
@DisplayName("Testy jednostkowe RezerwacjeKontroler z Mockito")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(MockitoExtension.class)
@Tag("controller")
@Tag("mockito")
class RezerwacjeKontrolerTest {
    
    @Mock
    private IHotelModel model;
    
    @InjectMocks
    private RezerwacjeKontroler kontroler;
    
    private Gosc testGosc;
    private Pokoj testPokoj;
    private Rezerwacja testRezerwacja;
    private LocalDate dataOd;
    private LocalDate dataDo;
    
    @BeforeEach
    void setUp() {
        testGosc = new Gosc(1, "Jan", "Kowalski", "jan@email.pl");
        testPokoj = new Pokoj(101, "dwuosobowy", 200.0);
        dataOd = LocalDate.now().plusDays(1);
        dataDo = LocalDate.now().plusDays(5);
        testRezerwacja = new Rezerwacja(1, dataOd, dataDo, testPokoj, testGosc);
    }
    
    @AfterEach
    void tearDown() {
        testGosc = null;
        testPokoj = null;
        testRezerwacja = null;
    }
    
    // ========== Testy tworzenia rezerwacji ==========
    
    @Test
    @Order(1)
    @DisplayName("utworzRezerwacje powinno delegować do modelu")
    void utworzRezerwacje_powinnoDelegowacDoModelu() {
        // given
        when(model.utworzRezerwacje(1, 101, dataOd, dataDo)).thenReturn(testRezerwacja);
        
        // when
        Rezerwacja wynik = kontroler.utworzRezerwacje(1, 101, dataOd, dataDo);
        
        // then
        assertAll(
            () -> assertNotNull(wynik),
            () -> assertEquals(testRezerwacja, wynik),
            () -> assertEquals(1, wynik.getId())
        );
        
        verify(model).utworzRezerwacje(1, 101, dataOd, dataDo);
    }
    
    @Test
    @Order(2)
    @DisplayName("utworzRezerwacje powinno przekazać wyjątek z modelu")
    void utworzRezerwacje_powinnoPrzekazacWyjatekZModelu() {
        // given
        when(model.utworzRezerwacje(anyInt(), anyInt(), any(), any()))
            .thenThrow(new IllegalArgumentException("Błąd walidacji"));
        
        // when & then
        assertThrows(
            IllegalArgumentException.class,
            () -> kontroler.utworzRezerwacje(1, 101, dataOd, dataDo)
        );
    }
    
    // ========== Testy anulowania rezerwacji ==========
    
    @Test
    @Order(3)
    @DisplayName("anulujRezerwacje powinno zwrócić true gdy anulowanie się powiodło")
    void anulujRezerwacje_powinnoZwrocicTrueGdyAnulowanieSiePowiodlo() {
        // given
        when(model.anulujRezerwacje(1)).thenReturn(true);
        
        // when
        boolean wynik = kontroler.anulujRezerwacje(1);
        
        // then
        assertTrue(wynik);
        verify(model).anulujRezerwacje(1);
    }
    
    @Test
    @Order(4)
    @DisplayName("anulujRezerwacje powinno zwrócić false gdy anulowanie się nie powiodło")
    void anulujRezerwacje_powinnoZwrocicFalseGdyAnulowanieSieNiePowiodlo() {
        // given
        when(model.anulujRezerwacje(999)).thenReturn(false);
        
        // when
        boolean wynik = kontroler.anulujRezerwacje(999);
        
        // then
        assertFalse(wynik);
    }
    
    @ParameterizedTest
    @Order(5)
    @DisplayName("anulujRezerwacje powinno obsługiwać różne ID rezerwacji")
    @ValueSource(ints = {1, 5, 10, 100, 999})
    void anulujRezerwacje_powinnoObslugiwacRozneIdRezerwacji(int rezerwacjaId) {
        // given
        when(model.anulujRezerwacje(rezerwacjaId)).thenReturn(rezerwacjaId < 100);
        
        // when
        boolean wynik = kontroler.anulujRezerwacje(rezerwacjaId);
        
        // then
        assertEquals(rezerwacjaId < 100, wynik);
        verify(model).anulujRezerwacje(rezerwacjaId);
    }
    
    // ========== Testy modyfikacji rezerwacji ==========
    
    @Test
    @Order(6)
    @DisplayName("modyfikujRezerwacje powinno delegować do modelu")
    void modyfikujRezerwacje_powinnoDelegowacDoModelu() {
        // given
        LocalDate nowaDataOd = LocalDate.now().plusDays(2);
        LocalDate nowaDataDo = LocalDate.now().plusDays(7);
        
        Rezerwacja zmodyfikowana = new Rezerwacja(1, nowaDataOd, nowaDataDo, testPokoj, testGosc);
        when(model.modyfikujRezerwacje(1, nowaDataOd, nowaDataDo)).thenReturn(zmodyfikowana);
        
        // when
        Rezerwacja wynik = kontroler.modyfikujRezerwacje(1, nowaDataOd, nowaDataDo);
        
        // then
        assertAll(
            () -> assertNotNull(wynik),
            () -> assertEquals(nowaDataOd, wynik.getDataOd()),
            () -> assertEquals(nowaDataDo, wynik.getDataDo())
        );
        
        verify(model).modyfikujRezerwacje(1, nowaDataOd, nowaDataDo);
    }
    
    // ========== Testy przeglądania rezerwacji ==========
    
    @Test
    @Order(7)
    @DisplayName("przegladajZarezerwowanePokoje powinno zwrócić listę rezerwacji")
    void przegladajZarezerwowanePokoje_powinnoZwrocicListeRezerwacji() {
        // given
        Rezerwacja rezerwacja2 = new Rezerwacja(2, dataOd.plusDays(10), dataDo.plusDays(10), testPokoj, testGosc);
        List<Rezerwacja> rezerwacje = Arrays.asList(testRezerwacja, rezerwacja2);
        
        when(model.znajdzRezerwacje(dataOd, dataDo.plusDays(15))).thenReturn(rezerwacje);
        
        // when
        List<Rezerwacja> wynik = kontroler.przegladajZarezerwowanePokoje(dataOd, dataDo.plusDays(15));
        
        // then
        assertAll(
            () -> assertNotNull(wynik),
            () -> assertEquals(2, wynik.size()),
            () -> assertTrue(wynik.contains(testRezerwacja))
        );
    }
    
    @Test
    @Order(8)
    @DisplayName("przegladajZarezerwowanePokoje powinno zwrócić pustą listę gdy brak rezerwacji")
    void przegladajZarezerwowanePokoje_powinnoZwrocicPustaListeGdyBrakRezerwacji() {
        // given
        when(model.znajdzRezerwacje(any(), any())).thenReturn(Collections.emptyList());
        
        // when
        List<Rezerwacja> wynik = kontroler.przegladajZarezerwowanePokoje(dataOd, dataDo);
        
        // then
        assertTrue(wynik.isEmpty());
    }
    
    // ========== Testy opłaty za anulowanie ==========
    
    @Test
    @Order(9)
    @DisplayName("pobierzOplateZaAnulowanie powinno zwrócić 20% ceny rezerwacji")
    void pobierzOplateZaAnulowanie_powinnoZwrocic20ProcentCenyRezerwacji() {
        // given - rezerwacja kosztuje 800 PLN, 20% = 160 PLN
        when(model.pobierzOplate(1)).thenReturn(800.0);
        
        // when
        double oplata = kontroler.pobierzOplateZaAnulowanie(1);
        
        // then
        assertEquals(160.0, oplata, 0.01);
        verify(model).pobierzOplate(1);
    }
    
    @ParameterizedTest
    @Order(10)
    @DisplayName("pobierzOplateZaAnulowanie powinno obliczać 20% dla różnych cen")
    @CsvSource({
        "100.0, 20.0",
        "500.0, 100.0",
        "1000.0, 200.0",
        "2500.0, 500.0"
    })
    void pobierzOplateZaAnulowanie_powinnoObliczac20ProcentDlaRoznychCen(
            double cenaRezerwacji, double oczekiwanaOplata) {
        // given
        when(model.pobierzOplate(anyInt())).thenReturn(cenaRezerwacji);
        
        // when
        double oplata = kontroler.pobierzOplateZaAnulowanie(1);
        
        // then
        assertEquals(oczekiwanaOplata, oplata, 0.01);
    }
    
    // ========== Testy polityki anulowania z terminem ==========
    
    @Test
    @Order(11)
    @DisplayName("obliczOplateZaAnulowanieZTerminem powinno zwrócić 0 gdy więcej niż 7 dni przed")
    void obliczOplateZaAnulowanieZTerminem_powinnoZwrocic0GdyWiecejNiz7DniPrzed() {
        // given - rezerwacja zaczyna się za 10 dni
        Rezerwacja przyszlaRezerwacja = new Rezerwacja(
            1,
            LocalDate.now().plusDays(10),
            LocalDate.now().plusDays(14),
            testPokoj,
            testGosc
        );
        
        when(model.znajdzRezerwacje(null, null)).thenReturn(List.of(przyszlaRezerwacja));
        when(model.pobierzOplate(1)).thenReturn(800.0);
        
        // when
        double oplata = kontroler.obliczOplateZaAnulowanieZTerminem(1);
        
        // then
        assertEquals(0.0, oplata, 0.01);
    }
    
    @Test
    @Order(12)
    @DisplayName("obliczOplateZaAnulowanieZTerminem powinno zwrócić 20% gdy 3-7 dni przed")
    void obliczOplateZaAnulowanieZTerminem_powinnoZwrocic20ProcentGdy3do7DniPrzed() {
        // given - rezerwacja zaczyna się za 5 dni
        Rezerwacja przyszlaRezerwacja = new Rezerwacja(
            1,
            LocalDate.now().plusDays(5),
            LocalDate.now().plusDays(9),
            testPokoj,
            testGosc
        );
        
        when(model.znajdzRezerwacje(null, null)).thenReturn(List.of(przyszlaRezerwacja));
        when(model.pobierzOplate(1)).thenReturn(800.0);
        
        // when
        double oplata = kontroler.obliczOplateZaAnulowanieZTerminem(1);
        
        // then
        assertEquals(160.0, oplata, 0.01); // 20% z 800
    }
    
    @Test
    @Order(13)
    @DisplayName("obliczOplateZaAnulowanieZTerminem powinno zwrócić 50% gdy 1-3 dni przed")
    void obliczOplateZaAnulowanieZTerminem_powinnoZwrocic50ProcentGdy1do3DniPrzed() {
        // given - rezerwacja zaczyna się za 2 dni
        Rezerwacja przyszlaRezerwacja = new Rezerwacja(
            1,
            LocalDate.now().plusDays(2),
            LocalDate.now().plusDays(6),
            testPokoj,
            testGosc
        );
        
        when(model.znajdzRezerwacje(null, null)).thenReturn(List.of(przyszlaRezerwacja));
        when(model.pobierzOplate(1)).thenReturn(800.0);
        
        // when
        double oplata = kontroler.obliczOplateZaAnulowanieZTerminem(1);
        
        // then
        assertEquals(400.0, oplata, 0.01); // 50% z 800
    }
    
    @Test
    @Order(14)
    @DisplayName("obliczOplateZaAnulowanieZTerminem powinno rzucić wyjątek dla nieistniejącej rezerwacji")
    void obliczOplateZaAnulowanieZTerminem_powinnoRzucicWyjatekDlaNieistniejacejRezerwacji() {
        // given
        when(model.znajdzRezerwacje(null, null)).thenReturn(Collections.emptyList());
        
        // when & then
        assertThrows(
            IllegalArgumentException.class,
            () -> kontroler.obliczOplateZaAnulowanieZTerminem(999)
        );
    }
    
    // ========== Testy weryfikacji wywołań ==========
    
    @Test
    @Order(15)
    @DisplayName("Weryfikacja liczby wywołań metod modelu")
    void weryfikacjaLiczbyWywolanMetodModelu() {
        // given
        when(model.utworzRezerwacje(anyInt(), anyInt(), any(), any())).thenReturn(testRezerwacja);
        when(model.anulujRezerwacje(anyInt())).thenReturn(true);
        when(model.znajdzRezerwacje(any(), any())).thenReturn(List.of(testRezerwacja));
        
        // when - wykonaj kilka operacji
        kontroler.utworzRezerwacje(1, 101, dataOd, dataDo);
        kontroler.utworzRezerwacje(2, 102, dataOd, dataDo);
        kontroler.anulujRezerwacje(1);
        kontroler.przegladajZarezerwowanePokoje(dataOd, dataDo);
        
        // then - weryfikuj liczbę wywołań
        verify(model, times(2)).utworzRezerwacje(anyInt(), anyInt(), any(), any());
        verify(model, times(1)).anulujRezerwacje(anyInt());
        verify(model, times(1)).znajdzRezerwacje(any(), any());
    }
}
