package pl.pwr.hotel.suite;

import org.junit.platform.suite.api.*;

/**
 * Zestaw testów dla warstwy DAO.
 * Zadanie 3: Zestawy testów z użyciem @Suite i @Tag.
 * 
 * Ten zestaw grupuje wszystkie testy oznaczone tagiem "dao":
 * - GoscieDAOTest
 */
@Suite
@SuiteDisplayName("Zestaw testów warstwy DAO")
@SelectPackages("pl.pwr.hotel.dao")
@IncludeTags("dao")
public class DAOTestSuite {
    // Klasa zestawu testów - nie wymaga implementacji
}
