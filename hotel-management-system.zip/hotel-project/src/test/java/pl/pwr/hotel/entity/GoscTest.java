package pl.pwr.hotel.entity;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Testy jednostkowe dla klasy Gosc.
 * Zadanie 1: Testy bez mockowania - testowanie operacji niezależnych.
 * 
 * Wymagania spełnione:
 * - @DisplayName dla wszystkich testów
 * - @Order do określenia kolejności
 * - @BeforeEach i @AfterEach
 * - Minimum 3 różne asercje
 * - 2 metody parametryzacji (@CsvSource, @ValueSource)
 */
@DisplayName("Testy jednostkowe klasy Gosc")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Tag("entity")
class GoscTest {
    
    private Gosc gosc;
    
    @BeforeEach
    void setUp() {
        // Przygotowanie obiektu testowego przed każdym testem
        gosc = new Gosc(1, "Jan", "Kowalski", "jan.kowalski@email.pl");
    }
    
    @AfterEach
    void tearDown() {
        // Czyszczenie po każdym teście
        gosc = null;
    }
    
    // ========== Testy konstruktorów ==========
    
    @Test
    @Order(1)
    @DisplayName("Konstruktor domyślny powinien utworzyć obiekt z wartościami null")
    void konstruktorDomyslny_powinienUtworzycObiektZWartosciamiNull() {
        // given & when
        Gosc nowyGosc = new Gosc();
        
        // then
        assertAll("Wartości domyślne",
            () -> assertEquals(0, nowyGosc.getId(), "ID powinno być 0"),
            () -> assertNull(nowyGosc.getImie(), "Imię powinno być null"),
            () -> assertNull(nowyGosc.getNazwisko(), "Nazwisko powinno być null"),
            () -> assertNull(nowyGosc.getEmail(), "Email powinien być null")
        );
    }
    
    @Test
    @Order(2)
    @DisplayName("Konstruktor z parametrami powinien poprawnie ustawić wszystkie pola")
    void konstruktorZParametrami_powinienPoprawnieUstawicWszystkiePola() {
        // then
        assertAll("Wartości z konstruktora",
            () -> assertEquals(1, gosc.getId()),
            () -> assertEquals("Jan", gosc.getImie()),
            () -> assertEquals("Kowalski", gosc.getNazwisko()),
            () -> assertEquals("jan.kowalski@email.pl", gosc.getEmail())
        );
    }
    
    // ========== Testy getterów i setterów ==========
    
    @Test
    @Order(3)
    @DisplayName("Setter i getter dla ID powinny działać poprawnie")
    void setId_getId_powinnyDzialacPoprawnie() {
        // when
        gosc.setId(100);
        
        // then
        assertEquals(100, gosc.getId());
    }
    
    @Test
    @Order(4)
    @DisplayName("Setter i getter dla imienia powinny działać poprawnie")
    void setImie_getImie_powinnyDzialacPoprawnie() {
        // when
        gosc.setImie("Adam");
        
        // then
        assertEquals("Adam", gosc.getImie());
    }
    
    @ParameterizedTest
    @Order(5)
    @DisplayName("Setter imienia powinien akceptować różne wartości")
    @ValueSource(strings = {"Anna", "Krzysztof", "Małgorzata", "Ę", "Żółć"})
    void setImie_powinienAkceptowacRozneWartosci(String imie) {
        // when
        gosc.setImie(imie);
        
        // then
        assertEquals(imie, gosc.getImie());
    }
    
    @Test
    @Order(6)
    @DisplayName("Setter i getter dla nazwiska powinny działać poprawnie")
    void setNazwisko_getNazwisko_powinnyDzialacPoprawnie() {
        // when
        gosc.setNazwisko("Nowak");
        
        // then
        assertEquals("Nowak", gosc.getNazwisko());
    }
    
    @Test
    @Order(7)
    @DisplayName("Setter i getter dla email powinny działać poprawnie")
    void setEmail_getEmail_powinnyDzialacPoprawnie() {
        // when
        gosc.setEmail("nowy@email.com");
        
        // then
        assertEquals("nowy@email.com", gosc.getEmail());
    }
    
    // ========== Testy metody getPelneNazwisko ==========
    
    @Test
    @Order(8)
    @DisplayName("getPelneNazwisko powinno zwrócić połączone imię i nazwisko")
    void getPelneNazwisko_powinnoZwrocicPolaczoneImieINazwisko() {
        // then
        assertEquals("Jan Kowalski", gosc.getPelneNazwisko());
    }
    
    @ParameterizedTest
    @Order(9)
    @DisplayName("getPelneNazwisko powinno poprawnie łączyć różne kombinacje imion i nazwisk")
    @CsvSource({
        "Anna, Nowak, Anna Nowak",
        "Krzysztof, Wiśniewski, Krzysztof Wiśniewski",
        "Żaneta, Żółkiewska, Żaneta Żółkiewska",
        "Jan, Kowalski-Nowak, Jan Kowalski-Nowak"
    })
    void getPelneNazwisko_powinnoPoprawnieLaczycRozneKombinacje(String imie, String nazwisko, String oczekiwane) {
        // given
        gosc.setImie(imie);
        gosc.setNazwisko(nazwisko);
        
        // then
        assertEquals(oczekiwane, gosc.getPelneNazwisko());
    }
    
    // ========== Testy rezerwacji ==========
    
    @Test
    @Order(10)
    @DisplayName("Nowy gość nie powinien mieć przypisanej rezerwacji")
    void nowyGosc_niePowinenMiecPrzypisanejRezerwacji() {
        // then
        assertNull(gosc.getRezerwacja());
    }
    
    @Test
    @Order(11)
    @DisplayName("Setter i getter dla rezerwacji powinny działać poprawnie")
    void setRezerwacja_getRezerwacja_powinnyDzialacPoprawnie() {
        // given
        Rezerwacja rezerwacja = new Rezerwacja();
        rezerwacja.setId(1);
        
        // when
        gosc.setRezerwacja(rezerwacja);
        
        // then
        assertNotNull(gosc.getRezerwacja());
        assertEquals(1, gosc.getRezerwacja().getId());
    }
    
    // ========== Testy equals i hashCode ==========
    
    @Test
    @Order(12)
    @DisplayName("Goście z tym samym ID powinni być równi")
    void equals_goscieZTymSamymId_powinniByRowni() {
        // given
        Gosc innyGosc = new Gosc(1, "Inna", "Osoba", "inna@email.pl");
        
        // then
        assertEquals(gosc, innyGosc);
    }
    
    @Test
    @Order(13)
    @DisplayName("Goście z różnymi ID nie powinni być równi")
    void equals_goscieZRoznymiId_niePowinniByRown() {
        // given
        Gosc innyGosc = new Gosc(2, "Jan", "Kowalski", "jan.kowalski@email.pl");
        
        // then
        assertNotEquals(gosc, innyGosc);
    }
    
    @Test
    @Order(14)
    @DisplayName("hashCode powinien być taki sam dla gości z tym samym ID")
    void hashCode_powinienBycTakiSamDlaGosciZTymSamymId() {
        // given
        Gosc innyGosc = new Gosc(1, "Inna", "Osoba", "inna@email.pl");
        
        // then
        assertEquals(gosc.hashCode(), innyGosc.hashCode());
    }
    
    @Test
    @Order(15)
    @DisplayName("equals z null powinno zwrócić false")
    void equals_zNull_powinnoZwrocicFalse() {
        // then
        assertNotEquals(null, gosc);
    }
    
    @Test
    @Order(16)
    @DisplayName("equals z innym typem obiektu powinno zwrócić false")
    void equals_zInnymTypemObiektu_powinnoZwrocicFalse() {
        // then
        assertNotEquals("string", gosc);
    }
    
    // ========== Testy toString ==========
    
    @Test
    @Order(17)
    @DisplayName("toString powinno zawierać wszystkie pola")
    void toString_powinnoZawieracWszystkiePola() {
        // when
        String wynik = gosc.toString();
        
        // then
        assertAll("Zawartość toString",
            () -> assertTrue(wynik.contains("id=1")),
            () -> assertTrue(wynik.contains("imie='Jan'")),
            () -> assertTrue(wynik.contains("nazwisko='Kowalski'")),
            () -> assertTrue(wynik.contains("email='jan.kowalski@email.pl'"))
        );
    }
}
