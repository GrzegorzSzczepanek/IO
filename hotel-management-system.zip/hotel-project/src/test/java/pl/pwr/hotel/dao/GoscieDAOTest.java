package pl.pwr.hotel.dao;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import pl.pwr.hotel.entity.Gosc;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Testy jednostkowe dla klasy GoscieDAO.
 * Zadanie 1: Testy bez mockowania - testowanie operacji DAO.
 * 
 * Wymagania spełnione:
 * - @DisplayName dla wszystkich testów
 * - @Order do określenia kolejności
 * - @BeforeEach i @AfterEach
 * - Minimum 3 różne asercje
 * - 2 metody parametryzacji (@CsvSource, @ValueSource)
 */
@DisplayName("Testy jednostkowe klasy GoscieDAO")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Tag("dao")
class GoscieDAOTest {
    
    private GoscieDAO goscieDAO;
    
    @BeforeEach
    void setUp() {
        goscieDAO = new GoscieDAO();
    }
    
    @AfterEach
    void tearDown() {
        goscieDAO.wyczyscWszystko();
        goscieDAO = null;
    }
    
    // ========== Testy zapisywania ==========
    
    @Test
    @Order(1)
    @DisplayName("zapisz powinno dodać nowego gościa z automatycznym ID")
    void zapisz_powinnoDodacNowegoGosciaZAutomatycznymId() {
        // given
        Gosc gosc = new Gosc(0, "Jan", "Kowalski", "jan@email.pl");
        
        // when
        goscieDAO.zapisz(gosc);
        
        // then
        assertAll(
            () -> assertEquals(1, gosc.getId(), "ID powinno być automatycznie ustawione na 1"),
            () -> assertEquals(1, goscieDAO.liczbaGosci(), "Powinien być 1 gość w bazie")
        );
    }
    
    @Test
    @Order(2)
    @DisplayName("zapisz powinno zachować istniejące ID jeśli większe od 0")
    void zapisz_powinnoZachowacIstniejaceId() {
        // given
        Gosc gosc = new Gosc(100, "Jan", "Kowalski", "jan@email.pl");
        
        // when
        goscieDAO.zapisz(gosc);
        
        // then
        assertEquals(100, gosc.getId());
    }
    
    @Test
    @Order(3)
    @DisplayName("zapisz nie powinno zapisywać null")
    void zapisz_niePowinnoZapisywacNull() {
        // when
        goscieDAO.zapisz(null);
        
        // then
        assertEquals(0, goscieDAO.liczbaGosci());
    }
    
    @ParameterizedTest
    @Order(4)
    @DisplayName("zapisz powinno poprawnie zapisywać wielu gości")
    @CsvSource({
        "Jan, Kowalski, jan@email.pl",
        "Anna, Nowak, anna@email.pl",
        "Piotr, Wiśniewski, piotr@email.pl"
    })
    void zapisz_powinnoPoprawnieZapisywacWieluGosci(String imie, String nazwisko, String email) {
        // given
        Gosc gosc = new Gosc(0, imie, nazwisko, email);
        
        // when
        goscieDAO.zapisz(gosc);
        
        // then
        Gosc zapisany = goscieDAO.pobierz(gosc.getId());
        assertAll(
            () -> assertNotNull(zapisany),
            () -> assertEquals(imie, zapisany.getImie()),
            () -> assertEquals(nazwisko, zapisany.getNazwisko()),
            () -> assertEquals(email, zapisany.getEmail())
        );
    }
    
    // ========== Testy pobierania ==========
    
    @Test
    @Order(5)
    @DisplayName("pobierz powinno zwrócić gościa po ID")
    void pobierz_powinnoZwrocicGosciaPoId() {
        // given
        Gosc gosc = new Gosc(0, "Jan", "Kowalski", "jan@email.pl");
        goscieDAO.zapisz(gosc);
        
        // when
        Gosc znaleziony = goscieDAO.pobierz(gosc.getId());
        
        // then
        assertNotNull(znaleziony);
        assertEquals(gosc.getId(), znaleziony.getId());
    }
    
    @Test
    @Order(6)
    @DisplayName("pobierz powinno zwrócić null dla nieistniejącego ID")
    void pobierz_powinnoZwrocicNullDlaNieistniejacegoId() {
        // when
        Gosc znaleziony = goscieDAO.pobierz(999);
        
        // then
        assertNull(znaleziony);
    }
    
    @Test
    @Order(7)
    @DisplayName("pobierzWszystkie powinno zwrócić pustą listę gdy brak gości")
    void pobierzWszystkie_powinnoZwrocicPustaListeGdyBrakGosci() {
        // when
        List<Gosc> wszyscy = goscieDAO.pobierzWszystkie();
        
        // then
        assertTrue(wszyscy.isEmpty());
    }
    
    @Test
    @Order(8)
    @DisplayName("pobierzWszystkie powinno zwrócić wszystkich gości")
    void pobierzWszystkie_powinnoZwrocicWszystkichGosci() {
        // given
        goscieDAO.zapisz(new Gosc(0, "Jan", "Kowalski", "jan@email.pl"));
        goscieDAO.zapisz(new Gosc(0, "Anna", "Nowak", "anna@email.pl"));
        goscieDAO.zapisz(new Gosc(0, "Piotr", "Wiśniewski", "piotr@email.pl"));
        
        // when
        List<Gosc> wszyscy = goscieDAO.pobierzWszystkie();
        
        // then
        assertEquals(3, wszyscy.size());
    }
    
    // ========== Testy usuwania ==========
    
    @Test
    @Order(9)
    @DisplayName("usun powinno usunąć istniejącego gościa")
    void usun_powinnoUsunacIstniejacegoGoscia() {
        // given
        Gosc gosc = new Gosc(0, "Jan", "Kowalski", "jan@email.pl");
        goscieDAO.zapisz(gosc);
        int id = gosc.getId();
        
        // when
        boolean wynik = goscieDAO.usun(id);
        
        // then
        assertAll(
            () -> assertTrue(wynik),
            () -> assertNull(goscieDAO.pobierz(id)),
            () -> assertEquals(0, goscieDAO.liczbaGosci())
        );
    }
    
    @Test
    @Order(10)
    @DisplayName("usun powinno zwrócić false dla nieistniejącego ID")
    void usun_powinnoZwrocicFalseDlaNieistniejacegoId() {
        // when
        boolean wynik = goscieDAO.usun(999);
        
        // then
        assertFalse(wynik);
    }
    
    // ========== Testy aktualizacji ==========
    
    @Test
    @Order(11)
    @DisplayName("aktualizuj powinno zaktualizować dane gościa")
    void aktualizuj_powinnoZaktualizowacDaneGoscia() {
        // given
        Gosc gosc = new Gosc(0, "Jan", "Kowalski", "jan@email.pl");
        goscieDAO.zapisz(gosc);
        
        // when
        gosc.setImie("Janusz");
        gosc.setEmail("janusz@email.pl");
        goscieDAO.aktualizuj(gosc);
        
        // then
        Gosc zaktualizowany = goscieDAO.pobierz(gosc.getId());
        assertAll(
            () -> assertEquals("Janusz", zaktualizowany.getImie()),
            () -> assertEquals("janusz@email.pl", zaktualizowany.getEmail())
        );
    }
    
    @Test
    @Order(12)
    @DisplayName("aktualizuj nie powinno nic robić dla nieistniejącego gościa")
    void aktualizuj_niePowinnoNicRobicDlaNieistniejacegoGoscia() {
        // given
        Gosc gosc = new Gosc(999, "Jan", "Kowalski", "jan@email.pl");
        
        // when
        goscieDAO.aktualizuj(gosc);
        
        // then
        assertNull(goscieDAO.pobierz(999));
    }
    
    // ========== Testy wyszukiwania ==========
    
    @Test
    @Order(13)
    @DisplayName("znajdzPoEmail powinno znaleźć gościa po adresie email")
    void znajdzPoEmail_powinnoZnalezcGosciaPoAdresieEmail() {
        // given
        Gosc gosc = new Gosc(0, "Jan", "Kowalski", "jan@email.pl");
        goscieDAO.zapisz(gosc);
        
        // when
        Gosc znaleziony = goscieDAO.znajdzPoEmail("jan@email.pl");
        
        // then
        assertNotNull(znaleziony);
        assertEquals("Jan", znaleziony.getImie());
    }
    
    @Test
    @Order(14)
    @DisplayName("znajdzPoEmail powinno zwrócić null dla nieistniejącego emaila")
    void znajdzPoEmail_powinnoZwrocicNullDlaNieistniejacegoEmaila() {
        // when
        Gosc znaleziony = goscieDAO.znajdzPoEmail("nieistnieje@email.pl");
        
        // then
        assertNull(znaleziony);
    }
    
    @ParameterizedTest
    @Order(15)
    @DisplayName("znajdzPoNazwisku powinno znaleźć gości o podanym nazwisku")
    @ValueSource(strings = {"Kowalski", "kowalski", "KOWALSKI"})
    void znajdzPoNazwisku_powinnoZnalezcGosciOPodanymNazwisku(String nazwisko) {
        // given
        goscieDAO.zapisz(new Gosc(0, "Jan", "Kowalski", "jan@email.pl"));
        goscieDAO.zapisz(new Gosc(0, "Anna", "Kowalski", "anna@email.pl"));
        goscieDAO.zapisz(new Gosc(0, "Piotr", "Nowak", "piotr@email.pl"));
        
        // when
        List<Gosc> znalezieni = goscieDAO.znajdzPoNazwisku(nazwisko);
        
        // then
        assertEquals(2, znalezieni.size());
    }
    
    // ========== Testy pomocnicze ==========
    
    @Test
    @Order(16)
    @DisplayName("liczbaGosci powinno zwrócić poprawną liczbę")
    void liczbaGosci_powinnoZwrocicPoprawnaLiczbe() {
        // given
        goscieDAO.zapisz(new Gosc(0, "Jan", "Kowalski", "jan@email.pl"));
        goscieDAO.zapisz(new Gosc(0, "Anna", "Nowak", "anna@email.pl"));
        
        // then
        assertEquals(2, goscieDAO.liczbaGosci());
    }
    
    @Test
    @Order(17)
    @DisplayName("wyczyscWszystko powinno usunąć wszystkich gości i zresetować licznik")
    void wyczyscWszystko_powinnoUsunacWszystkichGosciIZresetowacLicznik() {
        // given
        goscieDAO.zapisz(new Gosc(0, "Jan", "Kowalski", "jan@email.pl"));
        goscieDAO.zapisz(new Gosc(0, "Anna", "Nowak", "anna@email.pl"));
        
        // when
        goscieDAO.wyczyscWszystko();
        
        // then
        assertEquals(0, goscieDAO.liczbaGosci());
        
        // Sprawdź czy licznik został zresetowany
        Gosc nowyGosc = new Gosc(0, "Nowy", "Gosc", "nowy@email.pl");
        goscieDAO.zapisz(nowyGosc);
        assertEquals(1, nowyGosc.getId());
    }
}
