package pl.pwr.hotel.suite;

import org.junit.platform.suite.api.*;
import pl.pwr.hotel.entity.GoscTest;
import pl.pwr.hotel.entity.RezerwacjaTest;

/**
 * Zestaw testów dla warstwy encji.
 * Zadanie 3: Zestawy testów z użyciem @Suite.
 * 
 * Ten zestaw grupuje wszystkie testy klas encji:
 * - GoscTest
 * - RezerwacjaTest
 */
@Suite
@SuiteDisplayName("Zestaw testów warstwy encji")
@SelectClasses({
    GoscTest.class,
    RezerwacjaTest.class
})
@IncludeTags("entity")
public class EntityTestSuite {
    // Klasa zestawu testów - nie wymaga implementacji
}
