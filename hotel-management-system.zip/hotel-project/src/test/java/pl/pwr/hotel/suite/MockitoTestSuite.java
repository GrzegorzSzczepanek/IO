package pl.pwr.hotel.suite;

import org.junit.platform.suite.api.*;

/**
 * Zestaw testów wykorzystujących Mockito.
 * Zadanie 3: Zestawy testów z użyciem @Suite i @Tag.
 * 
 * Ten zestaw grupuje wszystkie testy oznaczone tagiem "mockito":
 * - HotelModelTest
 * - RezerwacjeKontrolerTest
 */
@Suite
@SuiteDisplayName("Zestaw testów z Mockito")
@SelectPackages("pl.pwr.hotel")
@IncludeTags("mockito")
public class MockitoTestSuite {
    // Klasa zestawu testów - nie wymaga implementacji
}
