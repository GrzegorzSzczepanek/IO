package pl.pwr.hotel.model;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import pl.pwr.hotel.dao.GoscieDAO;
import pl.pwr.hotel.dao.PokojeDAO;
import pl.pwr.hotel.dao.RezerwacjeDAO;
import pl.pwr.hotel.entity.Gosc;
import pl.pwr.hotel.entity.Pokoj;
import pl.pwr.hotel.entity.Rezerwacja;
import pl.pwr.hotel.factory.IGoscFactory;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Testy jednostkowe dla klasy HotelModel z użyciem Mockito.
 * Zadanie 2: Testy z mockowaniem zależności.
 * 
 * Wymagania spełnione:
 * - @Mock do tworzenia mocków
 * - @InjectMocks do wstrzykiwania mocków
 * - when().thenReturn() do konfiguracji zachowania
 * - verify() do sprawdzania wywołań
 * - @DisplayName, @Order, @BeforeEach/@AfterEach
 * - Minimum 3 różne asercje
 * - 2 metody parametryzacji
 */
@DisplayName("Testy jednostkowe HotelModel z Mockito")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(MockitoExtension.class)
@Tag("model")
@Tag("mockito")
class HotelModelTest {
    
    @Mock
    private RezerwacjeDAO rezerwacjeDAO;
    
    @Mock
    private PokojeDAO pokojeDAO;
    
    @Mock
    private GoscieDAO goscieDAO;
    
    @Mock
    private IGoscFactory fabrykaGosci;
    
    @InjectMocks
    private HotelModel hotelModel;
    
    private Gosc testGosc;
    private Pokoj testPokoj;
    private Rezerwacja testRezerwacja;
    
    @BeforeEach
    void setUp() {
        testGosc = new Gosc(1, "Jan", "Kowalski", "jan@email.pl");
        testPokoj = new Pokoj(101, "dwuosobowy", 200.0);
        testRezerwacja = new Rezerwacja(
            1,
            LocalDate.now().plusDays(1),
            LocalDate.now().plusDays(5),
            testPokoj,
            testGosc
        );
    }
    
    @AfterEach
    void tearDown() {
        testGosc = null;
        testPokoj = null;
        testRezerwacja = null;
    }
    
    // ========== Testy tworzenia rezerwacji ==========
    
    @Test
    @Order(1)
    @DisplayName("utworzRezerwacje powinno utworzyć rezerwację gdy wszystkie warunki spełnione")
    void utworzRezerwacje_powinnoUtworzycRezerwacjeGdyWarunkiSpelnione() {
        // given
        LocalDate dataOd = LocalDate.now().plusDays(1);
        LocalDate dataDo = LocalDate.now().plusDays(5);
        
        when(goscieDAO.pobierz(1)).thenReturn(testGosc);
        when(pokojeDAO.pobierz(101)).thenReturn(testPokoj);
        when(rezerwacjeDAO.czyPokojDostepny(101, dataOd, dataDo)).thenReturn(true);
        
        // when
        Rezerwacja wynik = hotelModel.utworzRezerwacje(1, 101, dataOd, dataDo);
        
        // then
        assertAll(
            () -> assertNotNull(wynik),
            () -> assertEquals(testGosc, wynik.getGosc()),
            () -> assertEquals(testPokoj, wynik.getPokoj()),
            () -> assertEquals(dataOd, wynik.getDataOd()),
            () -> assertEquals(dataDo, wynik.getDataDo()),
            () -> assertEquals(Rezerwacja.StatusRezerwacji.NOWA, wynik.getStatus())
        );
        
        // Weryfikacja wywołań
        verify(goscieDAO).pobierz(1);
        verify(pokojeDAO).pobierz(101);
        verify(rezerwacjeDAO).czyPokojDostepny(101, dataOd, dataDo);
        verify(rezerwacjeDAO).zapisz(any(Rezerwacja.class));
    }
    
    @Test
    @Order(2)
    @DisplayName("utworzRezerwacje powinno rzucić wyjątek gdy gość nie istnieje")
    void utworzRezerwacje_powinnoRzucicWyjatekGdyGoscNieIstnieje() {
        // given
        LocalDate dataOd = LocalDate.now().plusDays(1);
        LocalDate dataDo = LocalDate.now().plusDays(5);
        
        when(goscieDAO.pobierz(999)).thenReturn(null);
        
        // when & then
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> hotelModel.utworzRezerwacje(999, 101, dataOd, dataDo)
        );
        
        assertTrue(exception.getMessage().contains("nie istnieje"));
        verify(goscieDAO).pobierz(999);
        verify(rezerwacjeDAO, never()).zapisz(any());
    }
    
    @Test
    @Order(3)
    @DisplayName("utworzRezerwacje powinno rzucić wyjątek gdy pokój nie istnieje")
    void utworzRezerwacje_powinnoRzucicWyjatekGdyPokojNieIstnieje() {
        // given
        LocalDate dataOd = LocalDate.now().plusDays(1);
        LocalDate dataDo = LocalDate.now().plusDays(5);
        
        when(goscieDAO.pobierz(1)).thenReturn(testGosc);
        when(pokojeDAO.pobierz(999)).thenReturn(null);
        
        // when & then
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> hotelModel.utworzRezerwacje(1, 999, dataOd, dataDo)
        );
        
        assertTrue(exception.getMessage().contains("nie istnieje"));
    }
    
    @Test
    @Order(4)
    @DisplayName("utworzRezerwacje powinno rzucić wyjątek gdy pokój niedostępny")
    void utworzRezerwacje_powinnoRzucicWyjatekGdyPokojNiedostepny() {
        // given
        LocalDate dataOd = LocalDate.now().plusDays(1);
        LocalDate dataDo = LocalDate.now().plusDays(5);
        
        when(goscieDAO.pobierz(1)).thenReturn(testGosc);
        when(pokojeDAO.pobierz(101)).thenReturn(testPokoj);
        when(rezerwacjeDAO.czyPokojDostepny(101, dataOd, dataDo)).thenReturn(false);
        
        // when & then
        assertThrows(
            IllegalStateException.class,
            () -> hotelModel.utworzRezerwacje(1, 101, dataOd, dataDo)
        );
    }
    
    @Test
    @Order(5)
    @DisplayName("utworzRezerwacje powinno rzucić wyjątek dla nieprawidłowych dat")
    void utworzRezerwacje_powinnoRzucicWyjatekDlaNieprawidlowychDat() {
        // given - data zakończenia przed datą rozpoczęcia
        LocalDate dataOd = LocalDate.now().plusDays(5);
        LocalDate dataDo = LocalDate.now().plusDays(1);
        
        // when & then
        assertThrows(
            IllegalArgumentException.class,
            () -> hotelModel.utworzRezerwacje(1, 101, dataOd, dataDo)
        );
        
        verify(rezerwacjeDAO, never()).zapisz(any());
    }
    
    // ========== Testy anulowania rezerwacji ==========
    
    @Test
    @Order(6)
    @DisplayName("anulujRezerwacje powinno anulować istniejącą rezerwację")
    void anulujRezerwacje_powinnoAnulowacIstniejacaRezerwacje() {
        // given
        when(rezerwacjeDAO.pobierz(1)).thenReturn(testRezerwacja);
        
        // when
        boolean wynik = hotelModel.anulujRezerwacje(1);
        
        // then
        assertAll(
            () -> assertTrue(wynik),
            () -> assertEquals(Rezerwacja.StatusRezerwacji.ANULOWANA, testRezerwacja.getStatus())
        );
        
        verify(rezerwacjeDAO).pobierz(1);
        verify(rezerwacjeDAO).aktualizuj(testRezerwacja);
    }
    
    @Test
    @Order(7)
    @DisplayName("anulujRezerwacje powinno zwrócić false dla nieistniejącej rezerwacji")
    void anulujRezerwacje_powinnoZwrocicFalseDlaNieistniejacejRezerwacji() {
        // given
        when(rezerwacjeDAO.pobierz(999)).thenReturn(null);
        
        // when
        boolean wynik = hotelModel.anulujRezerwacje(999);
        
        // then
        assertFalse(wynik);
        verify(rezerwacjeDAO, never()).aktualizuj(any());
    }
    
    @Test
    @Order(8)
    @DisplayName("anulujRezerwacje powinno zwrócić false dla już anulowanej rezerwacji")
    void anulujRezerwacje_powinnoZwrocicFalseDlaJuzAnulowanejRezerwacji() {
        // given
        testRezerwacja.setStatus(Rezerwacja.StatusRezerwacji.ANULOWANA);
        when(rezerwacjeDAO.pobierz(1)).thenReturn(testRezerwacja);
        
        // when
        boolean wynik = hotelModel.anulujRezerwacje(1);
        
        // then
        assertFalse(wynik);
    }
    
    // ========== Testy wyszukiwania pokoi ==========
    
    @Test
    @Order(9)
    @DisplayName("znajdzDostepnePokoje powinno zwrócić listę dostępnych pokoi")
    void znajdzDostepnePokoje_powinnoZwrocicListeDostepnychPokoi() {
        // given
        LocalDate dataOd = LocalDate.now().plusDays(1);
        LocalDate dataDo = LocalDate.now().plusDays(5);
        
        Pokoj pokoj1 = new Pokoj(101, "jednoosobowy", 150.0);
        Pokoj pokoj2 = new Pokoj(102, "dwuosobowy", 200.0);
        Pokoj pokoj3 = new Pokoj(103, "apartament", 400.0);
        
        when(pokojeDAO.pobierzWszystkie()).thenReturn(Arrays.asList(pokoj1, pokoj2, pokoj3));
        when(rezerwacjeDAO.czyPokojDostepny(101, dataOd, dataDo)).thenReturn(true);
        when(rezerwacjeDAO.czyPokojDostepny(102, dataOd, dataDo)).thenReturn(false);
        when(rezerwacjeDAO.czyPokojDostepny(103, dataOd, dataDo)).thenReturn(true);
        
        // when
        List<Pokoj> dostepne = hotelModel.znajdzDostepnePokoje(dataOd, dataDo);
        
        // then
        assertAll(
            () -> assertEquals(2, dostepne.size()),
            () -> assertTrue(dostepne.contains(pokoj1)),
            () -> assertFalse(dostepne.contains(pokoj2)),
            () -> assertTrue(dostepne.contains(pokoj3))
        );
    }
    
    @ParameterizedTest
    @Order(10)
    @DisplayName("znajdzDostepnePokoje powinno rzucić wyjątek dla null dat")
    @MethodSource("dostawcaNullDat")
    void znajdzDostepnePokoje_powinnoRzucicWyjatekDlaNullDat(LocalDate dataOd, LocalDate dataDo) {
        // when & then
        assertThrows(
            IllegalArgumentException.class,
            () -> hotelModel.znajdzDostepnePokoje(dataOd, dataDo)
        );
    }
    
    static Stream<Arguments> dostawcaNullDat() {
        return Stream.of(
            Arguments.of(null, LocalDate.now().plusDays(5)),
            Arguments.of(LocalDate.now(), null),
            Arguments.of(null, null)
        );
    }
    
    // ========== Testy profilu gościa ==========
    
    @Test
    @Order(11)
    @DisplayName("utworzProfilGoscia powinno utworzyć nowego gościa")
    void utworzProfilGoscia_powinnoUtworzycNowegoGoscia() {
        // given
        when(goscieDAO.znajdzPoEmail("jan@email.pl")).thenReturn(null);
        when(fabrykaGosci.utworzGoscia("Jan", "Kowalski", "jan@email.pl")).thenReturn(testGosc);
        
        // when
        Gosc wynik = hotelModel.utworzProfilGoscia("Jan", "Kowalski", "jan@email.pl");
        
        // then
        assertAll(
            () -> assertNotNull(wynik),
            () -> assertEquals("Jan", wynik.getImie()),
            () -> assertEquals("Kowalski", wynik.getNazwisko())
        );
        
        verify(fabrykaGosci).utworzGoscia("Jan", "Kowalski", "jan@email.pl");
        verify(goscieDAO).zapisz(testGosc);
    }
    
    @Test
    @Order(12)
    @DisplayName("utworzProfilGoscia powinno rzucić wyjątek gdy email już istnieje")
    void utworzProfilGoscia_powinnoRzucicWyjatekGdyEmailJuzIstnieje() {
        // given
        when(goscieDAO.znajdzPoEmail("jan@email.pl")).thenReturn(testGosc);
        
        // when & then
        assertThrows(
            IllegalStateException.class,
            () -> hotelModel.utworzProfilGoscia("Jan", "Kowalski", "jan@email.pl")
        );
        
        verify(fabrykaGosci, never()).utworzGoscia(any(), any(), any());
    }
    
    @Test
    @Order(13)
    @DisplayName("znajdzProfilGoscia powinno zwrócić gościa po ID")
    void znajdzProfilGoscia_powinnoZwrocicGosciaPoId() {
        // given
        when(goscieDAO.pobierz(1)).thenReturn(testGosc);
        
        // when
        Gosc wynik = hotelModel.znajdzProfilGoscia(1);
        
        // then
        assertNotNull(wynik);
        assertEquals(testGosc, wynik);
        verify(goscieDAO).pobierz(1);
    }
    
    // ========== Testy opłat ==========
    
    @Test
    @Order(14)
    @DisplayName("pobierzOplate powinno zwrócić cenę rezerwacji")
    void pobierzOplate_powinnoZwrocicCeneRezerwacji() {
        // given - 4 noce po 200 PLN = 800 PLN
        when(rezerwacjeDAO.pobierz(1)).thenReturn(testRezerwacja);
        
        // when
        double oplata = hotelModel.pobierzOplate(1);
        
        // then
        assertEquals(800.0, oplata, 0.01);
    }
    
    @Test
    @Order(15)
    @DisplayName("pobierzOplate powinno rzucić wyjątek dla nieistniejącej rezerwacji")
    void pobierzOplate_powinnoRzucicWyjatekDlaNieistniejacejRezerwacji() {
        // given
        when(rezerwacjeDAO.pobierz(999)).thenReturn(null);
        
        // when & then
        assertThrows(
            IllegalArgumentException.class,
            () -> hotelModel.pobierzOplate(999)
        );
    }
    
    // ========== Testy aktualizacji statusu pokoju ==========
    
    @Test
    @Order(16)
    @DisplayName("aktualizujStatusPokoju powinno zaktualizować status")
    void aktualizujStatusPokoju_powinnoZaktualizowacStatus() {
        // given
        when(pokojeDAO.pobierz(101)).thenReturn(testPokoj);
        
        // when
        boolean wynik = hotelModel.aktualizujStatusPokoju(101, Pokoj.StatusPokoju.ZAJETY);
        
        // then
        assertAll(
            () -> assertTrue(wynik),
            () -> assertEquals(Pokoj.StatusPokoju.ZAJETY, testPokoj.getStatus())
        );
        
        verify(pokojeDAO).aktualizuj(testPokoj);
    }
    
    @ParameterizedTest
    @Order(17)
    @DisplayName("aktualizujStatusPokoju powinno obsługiwać różne statusy")
    @MethodSource("dostawcaStatusowPokoju")
    void aktualizujStatusPokoju_powinnoObslugiwacRozneStatusy(Pokoj.StatusPokoju status) {
        // given
        Pokoj pokoj = new Pokoj(102, "jednoosobowy", 150.0);
        when(pokojeDAO.pobierz(102)).thenReturn(pokoj);
        
        // when
        boolean wynik = hotelModel.aktualizujStatusPokoju(102, status);
        
        // then
        assertTrue(wynik);
        assertEquals(status, pokoj.getStatus());
    }
    
    static Stream<Arguments> dostawcaStatusowPokoju() {
        return Stream.of(
            Arguments.of(Pokoj.StatusPokoju.DOSTEPNY),
            Arguments.of(Pokoj.StatusPokoju.ZAJETY),
            Arguments.of(Pokoj.StatusPokoju.W_SPRZATANIU),
            Arguments.of(Pokoj.StatusPokoju.NIEDOSTEPNY)
        );
    }
    
    @Test
    @Order(18)
    @DisplayName("aktualizujStatusPokoju powinno zwrócić false dla nieistniejącego pokoju")
    void aktualizujStatusPokoju_powinnoZwrocicFalseDlaNieistniejacegoPokoju() {
        // given
        when(pokojeDAO.pobierz(999)).thenReturn(null);
        
        // when
        boolean wynik = hotelModel.aktualizujStatusPokoju(999, Pokoj.StatusPokoju.DOSTEPNY);
        
        // then
        assertFalse(wynik);
        verify(pokojeDAO, never()).aktualizuj(any());
    }
    
    // ========== Testy zameldowania i wymeldowania ==========
    
    @Test
    @Order(19)
    @DisplayName("zameldujGoscia powinno zmienić status rezerwacji na ZAMELDOWANA")
    void zameldujGoscia_powinnoZmienicStatusNaZameldowana() {
        // given
        testRezerwacja.setStatus(Rezerwacja.StatusRezerwacji.POTWIERDZONA);
        when(rezerwacjeDAO.pobierz(1)).thenReturn(testRezerwacja);
        
        // when
        boolean wynik = hotelModel.zameldujGoscia(1);
        
        // then
        assertAll(
            () -> assertTrue(wynik),
            () -> assertEquals(Rezerwacja.StatusRezerwacji.ZAMELDOWANA, testRezerwacja.getStatus()),
            () -> assertEquals(Pokoj.StatusPokoju.ZAJETY, testPokoj.getStatus())
        );
    }
    
    @Test
    @Order(20)
    @DisplayName("wymeldujGoscia powinno zmienić status rezerwacji na WYMELDOWANA")
    void wymeldujGoscia_powinnoZmienicStatusNaWymeldowana() {
        // given
        testRezerwacja.setStatus(Rezerwacja.StatusRezerwacji.ZAMELDOWANA);
        when(rezerwacjeDAO.pobierz(1)).thenReturn(testRezerwacja);
        
        // when
        boolean wynik = hotelModel.wymeldujGoscia(1);
        
        // then
        assertAll(
            () -> assertTrue(wynik),
            () -> assertEquals(Rezerwacja.StatusRezerwacji.WYMELDOWANA, testRezerwacja.getStatus()),
            () -> assertEquals(Pokoj.StatusPokoju.W_SPRZATANIU, testPokoj.getStatus())
        );
    }
}
