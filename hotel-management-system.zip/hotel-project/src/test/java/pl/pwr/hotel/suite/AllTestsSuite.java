package pl.pwr.hotel.suite;

import org.junit.platform.suite.api.*;

/**
 * Kompletny zestaw wszystkich testów.
 * Zadanie 3: Zestawy testów z użyciem @Suite.
 * 
 * Ten zestaw uruchamia wszystkie testy w pakiecie pl.pwr.hotel:
 * - Testy encji (entity)
 * - Testy DAO (dao)
 * - Testy modelu (model)
 * - Testy kontrolerów (controller)
 */
@Suite
@SuiteDisplayName("Kompletny zestaw testów systemu hotelowego")
@SelectPackages("pl.pwr.hotel")
@ExcludePackages("pl.pwr.hotel.suite")
public class AllTestsSuite {
    // Klasa zestawu testów - nie wymaga implementacji
}
