# System Zarządzania Hotelem - Projekt Laboratoryjny

## Opis projektu

Projekt implementuje system zarządzania hotelem zgodnie z diagramem klas UML z Visual Paradigm.
Zawiera pełną implementację klas encji, DAO, modelu, kontrolerów oraz testy jednostkowe
zgodne z wymaganiami laboratorium (JUnit 5, Mockito).

## Wymagania systemowe

- **Java JDK 17** lub nowsza
- **Apache Maven 3.8+**
- **IDE** (opcjonalnie): IntelliJ IDEA, Eclipse, NetBeans lub VS Code

---

## Instalacja na Windows

### 1. Instalacja Java JDK 17

**Opcja A - Instalator Oracle:**
1. Pobierz JDK z: https://www.oracle.com/java/technologies/downloads/#java17
2. Uruchom instalator `.exe`
3. Dodaj do zmiennej środowiskowej PATH:
   ```
   C:\Program Files\Java\jdk-17\bin
   ```
4. Ustaw JAVA_HOME:
   ```
   JAVA_HOME = C:\Program Files\Java\jdk-17
   ```

**Opcja B - Chocolatey (zalecane):**
```powershell
# W PowerShell jako Administrator
choco install openjdk17
```

**Opcja C - Winget:**
```powershell
winget install Microsoft.OpenJDK.17
```

### 2. Instalacja Maven

**Opcja A - Ręczna instalacja:**
1. Pobierz Maven z: https://maven.apache.org/download.cgi
2. Rozpakuj do `C:\Program Files\Apache\maven`
3. Dodaj do PATH:
   ```
   C:\Program Files\Apache\maven\bin
   ```
4. Ustaw M2_HOME:
   ```
   M2_HOME = C:\Program Files\Apache\maven
   ```

**Opcja B - Chocolatey:**
```powershell
choco install maven
```

### 3. Weryfikacja instalacji

```cmd
java -version
mvn -version
```

### 4. Rozpakowanie i uruchomienie projektu

```cmd
# Rozpakuj plik ZIP
tar -xf hotel-management-system.zip

# Przejdź do katalogu projektu
cd hotel-project

# Kompilacja projektu
mvn compile

# Uruchomienie wszystkich testów
mvn test

# Uruchomienie testów z raportem
mvn test -Dmaven.test.failure.ignore=true surefire-report:report
```

---

## Instalacja na macOS

### 1. Instalacja Java JDK 17

**Opcja A - Homebrew (zalecane):**
```bash
# Instalacja Homebrew (jeśli nie masz)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Instalacja OpenJDK 17
brew install openjdk@17

# Dodanie do PATH (dodaj do ~/.zshrc lub ~/.bash_profile)
echo 'export PATH="/opt/homebrew/opt/openjdk@17/bin:$PATH"' >> ~/.zshrc
echo 'export JAVA_HOME=$(/usr/libexec/java_home -v 17)' >> ~/.zshrc
source ~/.zshrc
```

**Opcja B - SDKMAN (zalecane dla programistów):**
```bash
# Instalacja SDKMAN
curl -s "https://get.sdkman.io" | bash
source "$HOME/.sdkman/bin/sdkman-init.sh"

# Instalacja Java 17
sdk install java 17.0.9-tem
sdk use java 17.0.9-tem
```

### 2. Instalacja Maven

**Homebrew:**
```bash
brew install maven
```

**SDKMAN:**
```bash
sdk install maven
```

### 3. Weryfikacja instalacji

```bash
java -version
mvn -version
```

### 4. Rozpakowanie i uruchomienie projektu

```bash
# Rozpakuj plik ZIP
unzip hotel-management-system.zip

# Przejdź do katalogu projektu
cd hotel-project

# Kompilacja projektu
mvn compile

# Uruchomienie wszystkich testów
mvn test

# Uruchomienie testów z szczegółowym wyjściem
mvn test -Dsurefire.useFile=false
```

---

## Uruchamianie testów

### Wszystkie testy
```bash
mvn test
```

### Konkretna klasa testowa
```bash
# Testy klasy Gosc
mvn test -Dtest=GoscTest

# Testy klasy Rezerwacja
mvn test -Dtest=RezerwacjaTest

# Testy DAO
mvn test -Dtest=GoscieDAOTest

# Testy z Mockito
mvn test -Dtest=HotelModelTest
mvn test -Dtest=RezerwacjeKontrolerTest
```

### Testy po tagach
```bash
# Tylko testy encji
mvn test -Dgroups=entity

# Tylko testy z Mockito
mvn test -Dgroups=mockito

# Tylko testy DAO
mvn test -Dgroups=dao
```

### Zestawy testów (Test Suites)
```bash
# Zestaw testów encji
mvn test -Dtest=EntityTestSuite

# Zestaw testów Mockito
mvn test -Dtest=MockitoTestSuite

# Zestaw testów DAO
mvn test -Dtest=DAOTestSuite

# Wszystkie testy przez suite
mvn test -Dtest=AllTestsSuite
```

### Konkretny test
```bash
# Pojedyncza metoda testowa
mvn test -Dtest=GoscTest#konstruktorDomyslny_powinienUtworzycObiektZWartosciamiNull
```

---

## Import do IDE

### IntelliJ IDEA

1. **File → Open**
2. Wybierz folder `hotel-project`
3. IntelliJ automatycznie wykryje projekt Maven
4. Poczekaj na pobranie zależności
5. **Uruchomienie testów:**
   - Kliknij prawym na `src/test/java` → **Run 'All Tests'**
   - Lub użyj skrótu `Ctrl+Shift+F10` (Windows) / `Cmd+Shift+R` (Mac)

### Eclipse

1. **File → Import → Existing Maven Projects**
2. Wybierz folder `hotel-project`
3. Kliknij **Finish**
4. **Uruchomienie testów:**
   - Kliknij prawym na projekt → **Run As → JUnit Test**

### VS Code

1. Zainstaluj rozszerzenia:
   - Extension Pack for Java
   - Test Runner for Java
2. **File → Open Folder** → wybierz `hotel-project`
3. **Uruchomienie testów:**
   - Otwórz panel Testing (ikona kolby)
   - Kliknij **Run All Tests**

---

## Struktura projektu

```
hotel-project/
├── pom.xml                          # Konfiguracja Maven
├── src/
│   ├── main/java/pl/pwr/hotel/
│   │   ├── entity/                  # Klasy encji
│   │   │   ├── Gosc.java
│   │   │   ├── Pokoj.java
│   │   │   ├── Rezerwacja.java
│   │   │   ├── IDodatek.java
│   │   │   ├── Sniadanie.java
│   │   │   └── Parking.java
│   │   ├── dao/                     # Warstwa dostępu do danych
│   │   │   ├── IDAO.java
│   │   │   ├── GoscieDAO.java
│   │   │   ├── PokojeDAO.java
│   │   │   └── RezerwacjeDAO.java
│   │   ├── factory/                 # Wzorzec Fabryka
│   │   │   ├── IGoscFactory.java
│   │   │   └── FabrykaGosci.java
│   │   ├── model/                   # Logika biznesowa
│   │   │   ├── IHotelModel.java
│   │   │   └── HotelModel.java
│   │   └── controller/              # Kontrolery
│   │       ├── IRezerwacjeKontroler.java
│   │       ├── RezerwacjeKontroler.java
│   │       ├── IGoscieKontroler.java
│   │       ├── GoscieKontroler.java
│   │       ├── IPokojeKontroler.java
│   │       └── PokojeKontroler.java
│   └── test/java/pl/pwr/hotel/
│       ├── entity/                  # Testy encji (Zadanie 1)
│       │   ├── GoscTest.java
│       │   └── RezerwacjaTest.java
│       ├── dao/                     # Testy DAO (Zadanie 1)
│       │   └── GoscieDAOTest.java
│       ├── model/                   # Testy z Mockito (Zadanie 2)
│       │   └── HotelModelTest.java
│       ├── controller/              # Testy kontrolerów (Zadanie 2)
│       │   └── RezerwacjeKontrolerTest.java
│       └── suite/                   # Zestawy testów (Zadanie 3)
│           ├── EntityTestSuite.java
│           ├── MockitoTestSuite.java
│           ├── DAOTestSuite.java
│           └── AllTestsSuite.java
```

---

## Spełnione wymagania laboratoryjne

### Zadanie 1: Testy bez mockowania
- ✅ Testy operacji niezależnych (gettery, settery, konstruktory)
- ✅ Testy operacji zależnych (obliczCene, dodajDodatek)
- ✅ `@DisplayName` dla wszystkich testów
- ✅ `@Order` do określenia kolejności
- ✅ `@BeforeEach` i `@AfterEach`
- ✅ Minimum 3 różne asercje (`assertEquals`, `assertTrue`, `assertNotNull`, `assertAll`)
- ✅ 2 metody parametryzacji (`@CsvSource`, `@ValueSource`, `@MethodSource`)

### Zadanie 2: Testy z Mockito
- ✅ `@Mock` do tworzenia mocków
- ✅ `@InjectMocks` do wstrzykiwania zależności
- ✅ `when().thenReturn()` do konfiguracji zachowania
- ✅ `verify()` do sprawdzania wywołań
- ✅ Testowanie wyjątków z `assertThrows`

### Zadanie 3: Zestawy testów
- ✅ `@Suite` do grupowania testów
- ✅ `@SelectClasses` do wyboru klas
- ✅ `@SelectPackages` do wyboru pakietów
- ✅ `@IncludeTags` do filtrowania po tagach

---

## Rozwiązywanie problemów

### "java: release version 17 not supported"
```bash
# Sprawdź wersję Java
java -version

# Upewnij się, że JAVA_HOME wskazuje na JDK 17
echo $JAVA_HOME  # Mac/Linux
echo %JAVA_HOME% # Windows
```

### "mvn: command not found"
```bash
# Mac - dodaj do PATH
export PATH="/opt/homebrew/opt/maven/bin:$PATH"

# Windows - sprawdź zmienną środowiskową PATH
```

### Problemy z zależnościami Maven
```bash
# Wyczyść cache Maven
mvn dependency:purge-local-repository

# Wymuś pobranie zależności
mvn clean install -U
```

### Testy nie działają w IDE
1. Odśwież projekt Maven (Maven → Reimport)
2. Sprawdź czy JUnit 5 jest na classpath
3. Zbuduj projekt: `mvn clean compile test-compile`

---

## Autor

Projekt wygenerowany na podstawie modelu UML z Visual Paradigm.
Politechnika Wrocławska - Inżynieria Oprogramowania
